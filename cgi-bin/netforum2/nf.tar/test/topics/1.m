===from:Andrew McCulloh
===email:netforum-dev@biostat.wisc.edu
===institution_site:http://www.biostat.wisc.edu/netforum
===institution:NetForum Development Team
===date:Thu Aug 22 20:00:29 1996
===subject:Test Message
===message:NetForum messages are easy to add, just click on the new messages button and fill out the form.
=========yorg=========
