===from:Brian Brand
===email:bbrand@iastate.edu
===date:Fri Oct 12 23:16:09 2001
===subject:Creation
===message:I agree with your group on the fact that the Big Bang theory and creation can be the same.  What about the rest of creation then?  Evolution could be the exact thing as the seven days in the Bible.  If you would go and read the first chapter in Genesis where it tells of creation, it states that creation happened in seven days.  It doesn't say how long the "days" are.  For all we know the days could be millions or even billions of years long.  Also, if you would look at the progression of how things were created, it follows the same pattern as evolution, so couldn't they both be the same thing?  One more thing, the Bible was written long before evolution was even thought through.  Is it possible that scientists are actually copying what the Bible has to say and making miniscule changes to say that creation is wrong and that science is right?
=========yorg=========
