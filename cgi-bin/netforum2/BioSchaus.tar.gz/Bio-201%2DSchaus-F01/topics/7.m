===from:Ariel Chandra
===date:Fri Sep 14 22:39:45 2001
===subject:hi
===message:Hi! I'm ariel chandra from Indonesia. I live in an apartment in sheldon and i'm taking bio 201 with prof. schauss. Hope i can make a lot of friends and discuss problems with you.
=========yorg=========
