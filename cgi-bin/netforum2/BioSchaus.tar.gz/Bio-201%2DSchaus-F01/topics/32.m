===from:Scott Schaus
===date:Thu Oct  4 23:39:54 2001
===subject:Honey Bee 
===message:Sharon:

Here's a URL with some excellent, extensive info on your questions.
<br>
http://maarec.cas.psu.edu/bkCD/HBBiology/breeding_genetics.htm
<br>
Yes, instrumental insemination (or AI) results in females (diploids), although it seems like the queen bee can "set aside" some of the sperm in a storage organ (spermatheca). Unfertilized eggs will be haploid, thus producing males (drones).
<br>
Scott 
=========yorg=========
