===from:Shane Smith
===date:Fri Nov  9 16:05:09 2001
===subject:http://www.hhmi.org/news/sternberg.html
===message:http://www.hhmi.org/news/sternberg.html
=========yorg=========
