===from:Zach Harryman
===date:Tue Aug 28 18:09:58 2001
===subject:All about me
===message:Hi, I'm from Cumming Iowa which is about 10 miles south of Des Moines.  I'm majoring in Forestry and would like to some day become a DNR officer.  I enjoy spending time with my girlfriend, hunting, fishing, and hanging out w/ friends. 
=========yorg=========
===from:Jeffery DeWall
===date:Tue Aug 28 18:13:21 2001
===subject:intro
===message:Hi!  I my name is Jeff DeWall and I am from a small town called Pocahontas.  This town of about 1500 people is located in the northwest corner of the state of Iowa.  I come from a family farm where we milk holstein cows and farrow sows.  When I am not working I like to do outdoor activities such as hunting, fishing and spending time with friends.
=========yorg=========
