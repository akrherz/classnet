===from:Jon
===date:Thu Nov  1 17:46:56 2001
===subject:SI material 11-01-01
===message:<pre>This material was used on 11-01-01 for a quiz-like session. It covers Chapters 29-31.

Plants I (Colonization of land) (Ch 29)


Plants most likely evolved from this green algae: (p 550)
Charophytes

The three kinds of adaptation that allowed plants to colonize land (p 546)
1) Structural (Roots, leaf-bearing shoots, etc.)
2) Chemical (Defense)
3) Reproductive (Spores)

Waxy cuticles are a form of this kind of product (p 547)
Secondary product (not produced by the mainstream metabolic pathways common in all plants)

In plants, it is a polymer that is resistant to almost all kinds of environmental damage (p 547)
Sporopollenin

A substance that hardens the cell walls of plants (p 547)
Lignin

A multicellular individual with haploid cells (p 548)
Gametophyte

A multicellular individual with diploid cells (p 548)
Sporophyte

A life cycle that includes both a multicellular haploid and diploid stage (p 548)
Alternation of generations

A name for the major divisions of plants (p 549)
Division

The first seed plants are in this division (p 549)
Gymnosperms

Alternation of generations in plants may have originated from this (p 550)
Delayed mitosis

Name 3 of 5 homologies between charophytes and plants (p 550)
1) Homologous chloroplasts
2) Biochemical similarity
3) Similar mechanisms of mitosis and cytokinesis
4) Similar sperm ultrastructure
5) Genetic relationship

The condition where gametes develop in a gametangia (p 552)
Embryophyte

The male gametangium which produces flagellated sperm (p 552)
Antheridium

The female gametangium where the egg is produced (p 552)
Archegonium

The first division to have an embryophyte (p 552)
Bryophytes

The dominant generation in the life cycle of bryophytes (p 552)
Gametophyte

The structure where bryophyte where the diploid Sporophyte produces haploid spores via meiosis (p 552)
Sporangium

The most diverse and widespread bryophytes (p 552)
Mosses (bryophyta)

The type of bryophyte which may reproduce asexually via gemmae (p 553)
Liverwort

The type of bryophyte that is most closely related to vascular plants (p 553)
Hornworts

Seedless vascular plants produced �coal forests� during what period (p 558)
Carboniferous

What lifecycle is dominant in seedless vascular plants (p 555)
Sporophyte

The Sporophyte of this type of plant produces only one type of spore (p 556)
Homosporous

This type of spore develops into female gametophytes bearing archegonia (p 556)
Megaspore
This type of spore develops into male gametophytes with antheridia (p 556)
Microspores

This division of seedless vascular plants includes club mosses (p 557)
Lycophytes (Lycophyta)

Another name for the division Sphenophyta
Horsetails

The most diverse plants seedless vascular plants
Ferns (Pterophyta)

 
Plant diversity II: The evolution of seed plants (Ch 30)

What replaced the spore as the main means on dispersing offspring in plants (p 562)
The seed

In seed plants, the mega sporangium is not a chamber but instead a solid, fleshy structure called this (p 563)
Nucellus

Additional layers of sporophyte tissues enveloping the megasporangium of seed plants (p 563)
Integuments

The name for the whole structure which includes integuments, nucellus, and megaspores (p 563)
Ovule

This group includes conifers, pines, and other plants with cones (p 549)
Gymnosperms

The great majority of modern-day plants are in this division (p 549)
Angiosperms

The division of gymnosperm which gets its name from its reproductive structure, a cluster of scale-like sporophylls (p 564)
Conifers (Coniferophyta)

This division of gymnosperms resembles palms and are even sometimes called sago palms (p 565)
Cycadophyta

This division has one species which is known as the maidenhair tree (p 565)
Ginkgophyta

This division of the gymnosperm lives only in the desert of southwest Africa and its strap-like leaves are the largest known leaves (p 565)
Gnetophyta

The most diverse and widespread type of plant (p 565)
Angiosperms

The cells that conduct water in conifers (p 567)
Tracheids

The two elements in angiosperms that evolved from tracheids (p 567)
Vessel elements and fiber

Transports water in angiosperms (p 567)
Xylem

Transports minerals and sugar in angiosperms (p 567)
Phloem

This structure encloses the flower before it opens (p 567)
Sepals

The sterile part of a plant other than petals (p 567)
Sepals

The male reproductive organ of an angiosperm (p 567)
Stamens

The sticky part of a carpel (p 568)
Stigma

The style in an angiosperm leads to this (p 568)
Ovary

A mature ovary in an angiosperm (p 568)
Fruit

The name for immature male gametophytes (p 568)
Pollen grains

A phenomenon where both sperm nuclei of an angiosperm pollen fertilize cells in the embryo sac (p 568)
Double fertilization

Another name for seed leaves (p 569)
Cotyledons

The triploid nucleus in the center of an embryo sac becomes this type of tissue (p 569)
Endosperm

The radiation of angiosperms marks the transition between which two eras (p 569)
Mesozoic to the Cenozoic

 
Fungi

Fungi are heterotrophs that acquire their nutrients by this method (p 574)
Absorption

The bodies of fungi (except yeasts) are constructed of units called this. (p 575)
Hyphae

This is a mat made of interwoven hyphae (p 575)
Mycelium

Cross-walls that divide hyphae (p 575)
Septa

Most fungi�s cell walls is composed of this (p 575)
Chitin

Another word for aseptate fungi which have no septa (p 576)
Coenocytic

The name for modified hyphae in parasitic fungi which have penetrating (predatory) tips (p 576)
Haustoria

The stage of syngamy which has the fusion of cytoplasm (p 576)
Plasmogamy

The stage of syngamy which has the fusion of nuclei (p 576)
Karyogamy

Formed after plasmogamy, this is where the two nuclei of the parents do not fuse (p 576)
Dikaryon

This division of fungi are mainly aquatic and are the only ones with a flagellated stage (p 577)
Chytridiomycota (Chytrids)

This division of fungi are mostly terrestrial and live in soil or on decaying plant and animal material (p 578)
Zygomycota

This is a type of mutualistic relationship with plants and zygomycota (p 578)
Mycorrhizae

Forms bread molds (p 578)
Zygomycota

This type of fungi creates sexual spores in asci (p 579)
Ascomycota

Ascomycota produces macroscopic fruiting bodies called (p 580)
Ascocarps

This division has long-lived dikaryotic mycelia and a transient diploid stage (p 581)
Basidiomycota (Club fungi)

This is a name for a type of fungi that produces asexually with spores (p 582)
Imperfect

This type of fungi reproduces asexually through budding (p 583)
Yeasts

A symbiotic association of millions of photosynthetic microorganisms held in a mesh (p 584)
Lichen

Makes up a lichen (p 584)
Algae and fungal hyphae

Small clusters of hyphae with embedded algae (p 584)
Soredia

A word meaning �fungus roots� (p 585)
Mycorrhizae

This division of fungus has an organism that causes Dutch elm disease (p 586)
Ascomycota
</pre>
=========yorg=========
