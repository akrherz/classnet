===from:Scott Schaus
===date:Thu Oct  4 23:21:01 2001
===subject:Inactivated X chromo
===message:The inactived X-chromosome can be reactivated and will decondense prior to meiosis. Each egg produced will have only one X chromo and it will be active. If this egg is fertilized by a sperm with an X chromo, then one of the X's will be randomly inactivated, and off we go through the whole series again.
<br>
HTH,
<br>
Scott
=========yorg=========
