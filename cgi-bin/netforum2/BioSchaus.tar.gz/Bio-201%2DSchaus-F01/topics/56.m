===from:allison polley
===date:Sun Oct 14 21:27:49 2001
===subject:group 10 reply
===message:Not everything in science is proven however. Theories are not proven, they just happen to have a significant amount of evidence supporting them. Also, you brought up the Bible but did not seem to believe that it was in fact a valid piece of evidence. But, for a great majority of people, it is believed that it is completely valid. So if religion is belived by so many, as are many scientific theories, isnt it also a universally vald form of knowledge. Also, the theory of evolution is NOT proven by anyone and many people have disproved it. Thats why so many scientists have come up with new ideas on how to make this theory more correct. It is still not perfect and more then likely will never be.
=========yorg=========
