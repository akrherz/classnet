===from:Janine Martin  
===date:Wed Oct 24 23:32:40 2001
===subject:Reply to Discussion
===message:I totally agree with what you guys are discussing.  Like someone who may have been a strong Christian growing up could turn away from God because they had something tragic happen like having a miscarriage or something.  At these low points people tend to turn away from God because they figure that if God was really there, he wouldn't have allowed this terrrible thing happen to them.  Experiences like that totally weigh on how you look at things, creation and evolution, believing in God, being and Athiest.  Experiences definately affect your view points on the world.
=========yorg=========
