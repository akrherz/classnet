===from:Blessie Zacharia
===date:Mon Oct 15 18:35:27 2001
===subject:message regarding
===message:Even if people are brought up in heavily religious families, it still does not deny the fact that religion and science do reach a crossing point. I myself was brought up in a Christian household, yet I find it hard to believe that the earth was created within 7 days.  All the evidence science suggests today outweighs the facts of religion, because all species did not exist back in the earliers eras, and also evolution can be observed through many species' origins.
=========yorg=========
