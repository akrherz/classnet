===from:Sharon Brown
===date:Sat Oct 20 10:36:01 2001
===subject:question
===message:What causes these rapid periods of change and what concludes them?  I do not view the end of dinosaurs as evolutionary proof.  If, of example an astroid was to hit the Earth and wipe out the Dinosaurs, no new species was a direct result of that action.  New speices were formed around that time, because new environments were left open for adaptive radiation, resulting in speciation.
=========yorg=========
