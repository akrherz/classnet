===from:Scott Schaus
===date:Thu Oct  4 23:55:53 2001
===subject:HIV resistance
===message:Hi:

Yeah, it would be conceivably possible someday with the genetic technology advances to engineer the HIV resistance. But, there are still way too many unknowns to just go in and select for the resistance.
<br>
Here's one for you: what "natural" method would increase the frequency of the mutant allele?
<br>
Scott
=========yorg=========
