===from:Brent Thompson
===email:brent75@iastate.edu
===date:Thu Nov  8 18:30:23 2001
===subject:Invertebrates
===message:This is a second posting for my  assignment #8.  I found a second website that better fit the description of the assignment.  The address to this website is: www.ahsc.arizona.edu/uac/notes/96classes/invclas.htm----

         

                         The University of Arizona has found recent advances using invertebrate models for Biomedical Research.  Marine Invertebrates have been used in studies such as: Neuronal Research, Immune Responsiveness, Environmental Toxicology and many more.  One research project for instance is researching the Molecular Pharmacology of the eye.  So with the use of Horseshoe crabs they study retinal photoreception and the electrical events which occur in the eye in different intensities of light and darkness.  This website was very interesting and has several more uses of invertebrates such as: corals, jellyfish, nematodes, leeches and many more. 

=========yorg=========
