===from:Lora Reznikov
===date:Thu Nov  8 16:45:32 2001
===subject:Invertebrates
===message:The article I found discusses Xenopus tadpoles.  They are researching how nervous systems function and allow animals to behave.  The first two days of life, the tadpole stays immobile, hanging by a strand of mucus secreted by a cement gland on the head.  Next, the tadpole can swim spontaneously if detached from the mucus, or if anything touches its body.  The tadpole stops swimming when the head bumps into solid objects and the tadpole reattaches.  The simple behavior is caused by a nervous circuit. At the time of hatchment, the spinal cord appears to have only eight different classes of neuron, but the tadpole can still swim.  I found this information at www.bio.bris.ac.uk/research/neuro/xgroup.htm 
=========yorg=========
