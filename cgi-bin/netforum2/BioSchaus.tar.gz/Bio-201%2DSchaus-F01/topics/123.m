===from:Alissa Fordice
===date:Thu Nov  8 11:47:44 2001
===subject:Assignment #8-- Zebra Mussels
===message:The site I found was from The Large River Studies Center(LRSC)which educates under grads about river ecosystems and their associated bodies of water.
The site reports findings related to the study of zebra mussels ecology, their predators, and the interactions of the mussels and other native species. Zebra mussels are frequently used for testing/experiments in various ways.  The link to the site is:  http://bio.winona.msus.edu/delong/zebra_mussel_research.htm
=========yorg=========
