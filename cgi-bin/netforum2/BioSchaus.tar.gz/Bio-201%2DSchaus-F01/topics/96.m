===from:Sharon Brown
===date:Sat Oct 20 10:42:40 2001
===subject:different eyes
===message:Are you asking why there are more than two different eye colors phenotypes in the population?  In that case, I belive the reason is because eye color has multiple alleles. Like in lecture when mm, Mm, and MM all had different phenotypes.  Or, are you asking why some people's eyes are a combination of green and brown or other colors?  I think that is very simmilar to the genes that carry skin color.  Just like skin color is varient from light to dark, eye color or brightness is probably the same.  However, I think you are asking about the minority of people who have one blue and one green eye.  There aren't many people like that, but I know it's possible.  My anut had a cat with one blue eye and one green eye.  I don't know what causes that, but I find it interesting.  If I fingure anything out, I will post it.
=========yorg=========
===from:Scott Schaus
===date:Mon Nov  5 11:21:10 2001
===subject:eye color
===message:In humans three genes involved in eye color are known. They explain typical patterns of inheritance of brown, green, and blue eye colors. However, they don't explain everything. Grey eye color, Hazel eye color, and multiple shades of blue, brown, green, and grey are not explained. The molecular basis of these genes is not known. What proteins they produce and how these proteins produce eye color is not known. Eye color at birth is often blue, and later turns to a darker color. Why eye color can change over time is not known. An additional gene for green is also postulated, and there are reports of blue eyed parents producing brown eyed children (which the three known genes can't easily explain [mutations, modifier genes that supress brown, and additional brown genes are all potential explanations]). 
<br><br>
The known Human Eye color genes are: EYCL1 (also called gey), the Green/blue eye color gene, located on chromosome 19 (though there is also evidence that another gene with similar activity exists but is not on chromosome 19). EYCL2 (also called bey1), the central brown eye color gene, possibly located on chromosome 15. EYCL3 (also called bey2), the Brown/blue eye color gene located on chromosome 15. A second gene for green has also been postulated. Other eye colors including grey and hazel are not yet explained. We do not yet know what these genes make, or how they produce eye colors. The two gene model (EYCL1 and EYCL3) used above explains only a portion of human eye color inheritance. Both additional eye color genes and modifier genes are almost certainly involved.
<br><br>
Try this URL for more info:<p>
http://www.athro.com/evo/inherit.html
=========yorg=========
