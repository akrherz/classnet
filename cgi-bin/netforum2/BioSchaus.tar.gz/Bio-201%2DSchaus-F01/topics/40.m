===from:Kelly Virgil
===email:kvirgil@iastate.edu
===date:Fri Oct 12 16:23:50 2001
===subject:Group 31 discussion
===message:Group 31 discussed question number 8 and we agree that Darwin made it possible for some to believe they are intellectually fulfilled athiests.  We believe that athiests can use Darwin's thery of evolution as proof that God didn't create everything.  Athiests could use published material as a sort of "bible."  We also discussed many possible errors in the bible that could lead others not to believe in creation.  We all feel that Darwin's evolutional theory has some errors as well.
=========yorg=========
