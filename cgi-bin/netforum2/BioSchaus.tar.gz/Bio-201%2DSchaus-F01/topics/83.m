===from:Josh Barnes
===email:jpbarnes@iastate.edu
===date:Tue Oct 23 17:26:50 2001
===subject:what
===message:You talked about Darwin the whole time, but never really gave an opinion of which one you believed in. Was creation a sole factor? or was Evolution the key ingredient? Did one come before the other, or did they just come along one day?
=========yorg=========
