===from:Paul Fisher
===date:Thu Nov  8 14:36:20 2001
===subject:Real Assighnment 8
===message:http://www.krasnow.gmu.edu/avrama/INLresearch.html
This web site is attempting to understand the biophysical and biochemical events used in memory storage of invertebrates.  The technique they are using is called classical conditioning with a combination of paired and unpaired stimuli.  This research is conducted by the Invertebrate Neurobiology Laboratory which is an interdisciplinary study group.  
=========yorg=========
