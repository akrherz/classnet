===from:allison polley
===date:Mon Oct 15 12:41:35 2001
===subject:group 45 reply
===message:I agree entirely with your ideas. I also believe that creation/evolution can coexist, even though their theories are almost completely contradicting. It is true that we really have no idea if a the day that the Bible speaks of is the same day as we know it.
=========yorg=========
