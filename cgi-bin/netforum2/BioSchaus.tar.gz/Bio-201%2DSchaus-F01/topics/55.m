===from:Amy Lensing
===email:alensing@iastate.edu
===date:Sun Oct 14 20:59:55 2001
===subject:reply to group #38
===message:Group #38~
good way of thinking and good theory behind it.  i never thought about the fact that it could be both! I just always assumed that it either had to support creation or evolution.

=========yorg=========
===from:megan mielnik
===date:Mon Oct 15 11:52:30 2001
===subject:reply
===message:I agree with your statement,"no living thing can evolve from nothing."  I think this actually supports creationism, which provides a starting point for life.  Th ebig bang theory leaves me wondering where did the matter come from.
=========yorg=========
