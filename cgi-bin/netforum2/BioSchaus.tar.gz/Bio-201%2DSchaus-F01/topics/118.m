===from:Kelli Kopf
===date:Thu Nov  8 16:34:38 2001
===subject:Treatment for infection of blood flukes
===message:Blood flukes are obtained by swimming or bathing in infested waters.  Some symptoms of infestation are a skin eruption at the site of entry of the fluke, fever, diarrhea, and various other symptoms depending on where the fluke is living.  Cirrhosis of the liver is common.  The disease can be cured with a drug called Praziquantel.  This drug gets rid of the fluke, however reinfection can occur.  All cases can result in general weakening and eventually death.  Control of this disease is difficult, although controlling the snail population is helpful.  
All of this information was found at www.encyclopedia.com/articles/11553.html
=========yorg=========
