===from:Dennis Portz
===date:Fri Nov  9  9:07:44 2001
===subject:Assign #8 Invertebrates
===message:http://nematode.unl.edu/wormsite.htm This is the 
University of Nebraska Nematode page. I thought that it 
was very interesting that there is a nematode society 
and they have there own web page! 

http://nematode.unl.edu/wormepns.htm
Nematodes as Biological Control Agents of Insects 
 
=========yorg=========
