===from:Lana Meyer, James Hauser, Jennifer Swenson, Krista Burich
===date:Mon Oct 15 21:29:35 2001
===subject:Debate
===message:We chose the Big Bang Theory to discuss and whether it contributed to evolutionism or creationism. We started out by saying what we most believed in.  There was one evolutionist, two creationists, and one who was in the middle.  Many of us agreed that there were a lot of evidence missing for both sides.  Evolutionists find it difficult to find transitional fossil evidence and there form of dating fossils by carbon is inaccurate.  There are holes in the creationism theory also.  Many don't know how literal the Bible should be taken, and many religious people are adapting aspects of the theory of evolution.  
Discussion also was split when we talked about the Big Bang Theory.  A creationist believed that it did not happen, therefore it does not contribute to the theory of creationism.  In the Big Bang Theory everything started with a single super force made up of strong nuclear, weak nuclear, electromagnetic, and gravity.  Together these things formed particles or protons and neutrons.  This is more evidence for evolution than creationism.  
Basically we discussed most about our own views on creationism and evolutionism than the Big Bang Theory itself.  But to fully say whether we believed if the Big Bang Theory contributed to creationism or evolutionism we had to understand our own views first.  

=========yorg=========
