===from:Josh Barnes
===email:jpbarnes@iastate.edu
===date:Mon Nov  5 13:12:12 2001
===subject:Invertebrates#2
===message:http://uncwil.edu/people/pawlikj/larvalbio.html

This website explains research of the settlement of sandcastle worms. They tell you background on this creature, and then tell you what they did and how it happened. For instance they put certain types of acids with the creature to see how they would respond. They also experimented with different types of tube sands and noticed that both larvaes they used had the same changes.

This article is very hard to understand so I didn't really understand everything.
=========yorg=========
