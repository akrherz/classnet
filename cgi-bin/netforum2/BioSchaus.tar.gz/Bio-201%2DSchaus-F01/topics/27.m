===from:Eric Giebelstein
===email:egiebels@iastate.edu
===date:Wed Sep 26 22:27:36 2001
===subject:test crossing
===message:I think the reason the test cross must be done with a homozygous recessive is because without the recessive test, you couldnt tell the unknown genotype from the offsprings' phenotypes which is the point of doing a tcross, there could be multiple combinations of the unknown's genotype.  If the test wasnt homozy. resessive  If the test genotype was anything but homozy. recessive there could be the possibility of masking the unknown resessive allele if there is one.  Just try some different punnett squares with different test with the same unknown.  You should see the difference there.                                Hope that helps a little.                                        Eric
=========yorg=========
