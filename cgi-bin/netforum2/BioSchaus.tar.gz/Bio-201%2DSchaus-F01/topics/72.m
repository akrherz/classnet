===from:Janine Martin
===date:Mon Oct 15 18:57:16 2001
===subject:Group #
===message:Okay, we're group # 14 that wrote this message, just so everyone knows.  Sorry!
        Janine Martin
=========yorg=========
