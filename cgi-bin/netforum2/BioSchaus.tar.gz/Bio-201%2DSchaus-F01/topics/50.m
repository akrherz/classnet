===from:Sharon Brown
===date:Sat Oct 13  9:52:55 2001
===subject:Darwin and Creationists
===message:I agree that it is possible to believe in Darwin's ideas and the theory of natural selection and creation at the same time; however, do you think that this conclusion stated at the end of your summary cancles the idea being debated?  If you can believe in Darwin's theories and creation, then Darwin didn't make it possible to be an intelligent atheist.  How does your group believe it is possible to believe in both theories?  Is it possible that God put us and the other creatures on this earth and we have evloved slightly from the origional form though microevolution and natural selection?  What does your group have to say in terms of the different body style or build of acient man?  How else does evoultion fall into the debate?
=========yorg=========
===from:Lindsay West
===date:Mon Oct 15 14:17:39 2001
===subject:true...
===message:I agree with you on the atheists aspect taken in your discussion.  However, many atheists may disagree.  But, it's a very intelligent point.  If atheists are fairly informed on these matters, it gives them a way to back up thier beliefs.  The appeal of evolution is thought to provide a way for people to justify themselves that there is no God, so they can live and do as they want.  So, in reality it just makes them feel better about what they do and helps them to look past any consequences others may believe in.
=========yorg=========
===from:Blessie Zacharia
===date:Mon Oct 15 18:41:53 2001
===subject:both are possible
===message:My group discussed the same point, and concluded on the fact that both theories are possible of occuring. God could have created the world, and then species may have begun to evolve gradually over time, like Darwin suggests. Darwin's theory is merely that of evolution, not that of creation.
=========yorg=========
