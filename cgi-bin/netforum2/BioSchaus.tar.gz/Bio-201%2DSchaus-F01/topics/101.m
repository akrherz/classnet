===from:Janessa Christensen
===email:jchriste@iastate.edu
===date:Tue Nov  6 14:34:26 2001
===subject:Invertebrate Research Link
===message:http://www.ncl.ac.uk/neuroscience/research/insectvision/insectvision.phphttp://www.ncl.ac.uk/neuroscience/research/insectvision/insectvision.php

This site is from the Dept. of Neuroscience at the University of Newcastle.  The reseach being done is on invertebrate visual systems and how information passes from stage to stage and in turn how that information controls animal behavior.  The reseach has been focusing on species of locus and a collision dector called LGMD.  They have also been studying a second visual system, the simple eye or ocelli.
=========yorg=========
===from:Erin Brown
===date:Tue Nov  6 20:14:21 2001
===subject:Invertebrate Research Link
===message:The web site I found was www.darwinfoundation.org/articles/br15049805.html.  This site discussed research by three different teams into the terrestrial invertebrates of the Galapagos islands.  The research of the teams from Canada, Belgium, and Austria has identified enough new species of arthropods to more than double their previous knowledge.  They also have researched the effect introduction of new arthropod species to the islands has had on the native species, and how El Ni�o affects the colonization process.  The site also details how the Belgian team identified several species and how they determined the evolutionary history of other species.
=========yorg=========
===from:Jill Eggers
===date:Tue Nov  6 22:04:08 2001
===subject:assignment 8
===message:The link I found is www.geocities.com/athens/parthenon/6853/inv.html

This site is excellent for studying invertebrates.  It gives a summary of the types of invertebrates and what makes up the different classes.  There are outlines of the phylum and classes and also a link to a review sheet for invertebrates.  
=========yorg=========
===from:Alicia Janas
===email:ajanas@iastate.edu
===institution_site:http://www.mdsg.umd.edu/Research/R_ODR-08.html
===institution:Maryland Sea Grant
===date:Wed Nov  7  6:30:05 2001
===subject:Assignment #8
===message:This web page and it's link (http://www.research.mdsg.umd.edu/FMPro) discuss research on selective breeding for oysters in order to select breeds that are resistant to Dermo disease and the parasite Haplosporidium nelsoni that causes MSX.  Horn Point Laboratory's goal is to assess the improvement in CROSBreed (Cooperative Regional Oyester Selective Breeding project) stocks comparatively to other oysters, and conclude if these oysters will be significant in the restoration of Chesapeake Bay's oyster populations.  In the future, the research team's aspiration is to produce two more generations that are resistant to Dermo and MSX through selective breeding that can be used commercially and environmentally.
=========yorg=========
===from:Caleb Bergmann
===date:Wed Nov  7 11:07:28 2001
===subject:Assignment #8
===message:http://www.zmuc.dk/commonweb/5yrs/2resea00.htm
This site just discussed 31 phyla that they establish definately for the animal kingdom 
=========yorg=========
===from:Penny Hanson
===email:phanson@iastate.edu
===institution_site:http://www.ucmp.berkeley.edu/platyhelminthes/platyhelminthes.html
===institution:Berkeley
===date:Wed Nov  7 18:55:28 2001
===subject:Assignment #8, Research on invertebrates
===message:This link gives detailed information on platyhelminthes, or flatworms. There are three groups of flatworms. The first two are paraphyletic, or may descend from a common ancestor. There is also almost no fossil record of them, but have been found everywhere from Egyptian mummies to the dung of ground slothes. Enjoy!
=========yorg=========
===from:Sarah Warren
===date:Wed Nov  7 19:56:55 2001
===subject:Squids
===message:http://link.springer.de/link/service/journals/00898/fpapers/9004001/90040001.htm


The vampire squid (Vampyroteuthis infernalis) is a cepholopod that lives in parts of the ocean that have extremely low amounts of availible oxygen.  Therefore, it must adapt special ways to maximize its uptake of oxygen.  Some of the ways it does this are by having extremely large gill surfaces.  Also, one of the oxygen binding proteins, haemocyanin, has a very high oxygen affinity.   Most surprising was the high diffusion capacity compared to the metabolic rate of the vampire squid when compared to other cephalopods.    
=========yorg=========
===from:Deanna Greene
===institution_site:http://www.museum.tulane.edu/museum/research.edu
===institution:Tulane University
===date:Thu Nov  8 14:54:44 2001
===subject:Assignment #8
===message:I found a webpage for the Tulane University Museum of Natural History.  The site is: http://www.museum.tulane.edu/museum/research.edu.
From there, click on Invertebrate Research.  It shows what different professors are researching.  The college research mostly deals with freshwater and marine fish of the Gulf South.  They also deal with systematics and ecology.
=========yorg=========
===from:Blessie Zacharia
===date:Thu Nov  8 15:51:21 2001
===subject:Assign #8
===message:I found a link to the Invertebrate Department of the Smithsonian Institution.  Research here mainly consists of crustaceans, because they represent the largest biomass of marine animals.  Other research includes insects, echinoderms, mollusks, and worms.  The research they perform focuses on systematics, geographical distribution of invertebrates, relationships between invertebrates and other organisms, and overall ecology.
<a href="http://www.nmnh.si.edu/departments/invert.html/">Invertebrate Research at Smithsonian Institution</a>
=========yorg=========
===from:Megan Gjerde
===email:mgjerde@iastate.edu
===date:Thu Nov  8 16:10:41 2001
===subject:Invertebrate research Link
===message:I found this site at www.darwinfoundation.org/articles/br15049805.html. In this site there are different research teams that are gathering data to use see how the weather,like El Ni�o,effects the invertebrate populance.  They are also gathering data in which they monitor the changes in the major islands of the Gal�pagos due to tourists and accidental introductions to the climate. There is a section where they study the speciation in carabid beetles and lycosid spiders. In the future this data collected can be used in how to make stricter policies regarding tourists in the Gal�pagos National Park because whenever new things are introduced to the environment it can have effects that these sciencists are trying to find out whether it is good or not.
=========yorg=========
===from:Kelli Kopf
===date:Thu Nov  8 16:48:31 2001
===subject:Assignment #8: Jellyfish Populations
===message:The webpage I found was about jellyfish.  Mike Kingsford and Kylie Pitt are studying the abundancy and size of the C. mosaicus jellyfish at different times of the year.  The samples were taken from various sheltered waterways in Australia.  The results show that the jellyfish numbers were low in March, and by July the number of jellyfish per 1500m3 rose from about 250 to 280.  Kingsford and Pitt propose that the alternation in abundancy is due to changes in the temperature and salinity of the water.  This information can be found at www.bio.usyd.edu.au/CURRENT/blub.htm.
=========yorg=========
===from:Amy McCarthy
===date:Thu Nov  8 17:01:55 2001
===subject:Invertebrate Research
===message:I found the website 
www.mdsg.umd.edu/research/portfolios/ddrp/index.ht
m, which talks about the research being done on 
oysters and other invertebrates in the Chesapeake Bay 
area.  Over the past 10 years, oysters have been 
declining in number.  They are trying to find a way in 
which to keep oyster production along with fish 
populations up.  The National Sea Grant College 
Program has been providing money for the needed 
research.
=========yorg=========
===from:Kellen Ludvigson
===email:kludvig@iastate.edu
===date:Thu Nov  8 19:56:53 2001
===subject:Chironomous tentans research!
===message:http://www.fscwv.edu/users/pyeager/Res%20Summar.html


The author of this article used many very large words, some of which were not even in a 2300 page unabridged dictionary, however, this is what I got out of the article.  Under Microbial Research Summary, he researched the relationship of the microbial community of Lake Erie to the fine particulate organic matter content.  In other words, he wanted to see if there was a significant structure and function diference among microbes that were in different areas of the lake with different fine particulate organic matter concentration.  He took a sieve and strained the water and its contents into 5 seperate fractions, or samples.  After he analyzed each fraction over many months, he found there was not a significant difference among microbes over a different fine particulate organic matter gradients.   
=========yorg=========
===from:Patrick Hoffmann
===email:pathoff@iastate.edu
===institution:Bio 201- Schaus
===date:Thu Nov  8 20:14:53 2001
===subject:Invertebrate Research
===message:http://museums.gov.ns.ca/mnh/nature/nhs.y11/t11-16.pdf

   My site did it's research in Nova Scotia comparing land and fresh water invertebrates.  Their studies show that insects where obviously the most numerous, followed by arachnids.  They collected very little about the phyla protozoa through Nematoda.  They claim this due to Nova Scotias location and the barrier to the easy natural spread of plants and animals into the province.

  * If you go to page 2 of this report you will find a very interesting graph of their results.
=========yorg=========
===from:Erika Bolin
===email:erikab@iastate.edu
===date:Thu Nov  8 20:15:32 2001
===subject:Ammonites
===message:www.dmns.org/denverbasin2/fossil/invertres.html

This is a website devoted to the research of Ammonites, which are distant, extinct relatives of modern cephalopods, including the squid, octopus, and nautilus.  This research was done by a class for a museum in Denver, Colorado.  The research mainly covers the features of the giant ammonites, such as suture lines, scavenging marks, burrows, and compression cracks.
=========yorg=========
===from:Heather Williams
===date:Thu Nov  8 21:10:50 2001
===subject:Coral research
===message:Dr. William Fitt at the University of North Carolina at Wilmington conducted research measuring the condition of coral throughout the season related to bleaching and coral growth.  The results showed that all corals bleach no matter what color they appear.  Dr. Fitt's research also showed that corals spawn when there is little energy available and during seasons of great physiological stress. 
=========yorg=========
===from:zach harryman
===date:Thu Nov  8 21:45:41 2001
===subject:coral reef research
===message:http://www.coralreef.org/coralreefinfo/threats.htm    i found a site on coral reef research, and it mainly talked about how the were be depleated.  it said polution was the leading cause of coral degradation.  it also talked about how gas and oil spills were depleating it also.  it finally talked about how coral mining was destroying them also.
=========yorg=========
===from:Jeff Dewall
===date:Thu Nov  8 22:10:28 2001
===subject:Invertabrate link
===message:<a href="http://www.cnidaria.org/cri/research.html">Jellyfish research</a><p>  

The Cnidarian Research insitute is doing research on many forms of cnidaria.  One form of research is that they are trying to use cnidarians in human medical reseach.  Another project they are researching is the reproductive cues of jellyfish. 
=========yorg=========
===from:Brent Thompson
===email:brent75@iastate.edu
===date:Thu Nov  8 22:18:21 2001
===subject:Biology Assignment #8
===message:This is a second posting for my assignment #8. I found a second website that better fit the description of the assignment. The address to this website is: www.ahsc.arizona.edu/uac/notes/96classes/invclas.htm--- The University of Arizona has found recent advances using invertebrate models for Biomedical Research. Marine Invertebrates have been used in studies such as: Neuronal Research, Immune Responsiveness, Environmental Toxicology and many more. One research project for instance is researching the Molecular Pharmacology of the eye. So with the use of Horseshoe crabs they study retinal photoreception and the electrical events which occur in the eye in different intensities of light and darkness. This website was very interesting and has several more uses of invertebrates such as: corals, jellyfish, nematodes, leeches and many more. 

=========yorg=========
===from:Jackie Hanna
===email:jhanna@iastate.edu
===date:Thu Nov  8 23:06:21 2001
===subject:#8 assignment
===message:The site that I found was the Scripps Institution of Oceanography under the Marine Research Division.  The research was conducted by graduate students looking for new pharmaceutical agents from marine invertebrates such as anti-cancer, anti-fungal, and anti-inflammatory agents. Defensive Chemicals of marine invertebrates were also part of the research. Many other of their research interests are discussed at: www. mrd.ucsd.edu/jf/.
=========yorg=========
===from:allison polley
===date:Thu Nov  8 23:37:08 2001
===subject:assignment #8
===message:My website was basically about how to understand the relationship between evolution and invertebrates. The man did many experiments to try and solve evolution in this group at a deeper level. He mainly studied marine invertebrates and also looked at genetic variation to try to solve his question. The study of larvae in major ocean currents was also an important part of his study.
http://www.biol.sc.edu/~coull_lab/staton/joeres.html
=========yorg=========
===from:Krista Williams
===email:kris82@iastate.edu
===institution_site:http://www.nps.gov/bibe/iar/invertebrate.htm
===institution:invertebrate investigators
===date:Thu Nov  8 23:43:07 2001
===subject:Invertebrate Research
===message:This site mainly show the reports of different scientists and the research they have done with different invertebrates. The postings from each scientist are short, but they do show results of research with scorpions and isopods. All of the research was conducted at Big Bend National Park.
=========yorg=========
===from:Sharon Brown
===email:scbrown@iastate.edu
===date:Fri Nov  9 10:08:36 2001
===subject:Sharon Brown (Assignment #8): 
===message:Sharon Brown�s invertebrate research website posting and short summary:  The website entitled �Control Gene Found for Worms, Invertebrates� is found at: http://www.instadv.ucsb.edu/93106/2001/april16/gene/gene.html.  The site suggests that humans and worms are similar in development.  Joel Rothman states, �We found that a key regulator of early development is the same in worms and vertebrates.�  By studying the development of nematode worms and noting how development can go wrong, we might be able to learn more about human birth defects.  Researches found a common regulator gene that controls formation of internal organs.  This particular gene is responsible for telling cells which type of tissue cell to become.  The lab identified and studied mutant worms that are defective in early development.  The main goals for the project were to determine how the genes work, what when wrong, and most importantly how it can be fixed.  Rothman believes that by studying genetic switches, such as the ones that affect the embryonic development of nematode worms, eventually these switches will be used in tissue engineering.  Within the next few decades, he claims that we will have the technology to �turn these switches on and grow a replacement organ in the lab�.  Overall, the research on the early development of nematodes is beneficial on several levels, including the information that is gains in terms of human birth defects, as well as gene switch discovers that could lead to genetic engineering.  
=========yorg=========
===from:Renee Steffens
===date:Fri Nov  9 10:31:49 2001
===subject:Invertebrates---bees!!
===message:Bees aren't just for hunny making!  According to research I found at a site for the University of Montana.  Where they bees to find explosives, drugs, and military unique chemicals in our environment.  This research has helped in the investigation of the devostating Chernobl accident. 
Here's the site!
http://biology.dbs.umt.edu/bees/active.htm  
=========yorg=========
===from:Megan Beattie
===email:mbeattie@iastate.edu
===date:Fri Nov  9 11:07:09 2001
===subject:Assignment #8
===message:I found the link to the National Resource Center for Cephalopods ( http://www.nrcc.utmb.edu/AlliedResPrgs2.htm ).  This site has various research projects on mariculture and bioengineering, ethology and adaptive coloration, nutrition and physiology, and neurobiology.  Mariculture focuses on the squid Sepioteuthis lessoniana and the cuttlefish Sepia officinalis.  The research is organized into four areas: (1) feeding behavior, (2) chemical attractants, (3) palatability and digestibility and (4) growth trials.  The ethology and adaptive coloration research deals with squids because they are highly interactive, social cephalopods, and they are continually communicating with one another through color patterns, postures and movements. The research deals with the coloration with aggression, in the establishment of dominance hierarchies, in mate selection, and in other ways.  There is also information about the evolution and anatomy of the cephalopods.  This site also posted many links to other sites involving reasearch.
=========yorg=========
===from:Kevin Kasper
===date:Fri Nov  9 11:09:47 2001
===subject:Invertebrate research
===message:The site http://elegans.swmed.edu/ shows research on various organisms. One on the organisms it researchs on in the roundworm. In the 1960's Sydney Brenner began to study the genetics of development and neurobiology. Since then the community of C elegans researchers has expanded to over a thousand. This site has other links for more information on nematodes.
=========yorg=========
===from:Lana Meyer
===date:Fri Nov  9 13:06:26 2001
===subject:Cnidaria Research
===message:At www.cnidaria.org/cri/research.html there is a list of a number of ways they are researching cnidarians.   They are studying jellyfish nutrition and some reproduction methods.  They are also doing medical research on the use of cnidarians in human research.  Another invertebrate they study are coral and how bio-organic molecules are used in coral defense.  They do no go into detail about their projects but they do give a list of them.  The research come from the Cnidarian Research Institute.  
=========yorg=========
===from:Pam Haluska
===institution:Zebra Mussels--http://bio.winona.msus.edu/delong/invertebrate_studies.htm
===date:Fri Nov  9 13:37:06 2001
===subject:Assignment 8
===message:This website talked about invertebrate research with the Large River Studies Center from 1994-1999.  They have used zebra mussels to research a variety things.  They have found that there is a strong relationship between the small increase in discharge and increased zebra mussel recruitment.  Also, that the growth rates were highest in the middle of a navigation reach where conditions are most like pre-dam conditions, and that they exhibit different population dynamics in the main channel than in back waters. The last thing they have found was that predators have an effect on zebra mussel population structure in the upper Mississippi River but not in the Ohio River.
=========yorg=========
===from:Kayla Schulte
===date:Fri Nov  9 14:14:20 2001
===subject:Assignment 8
===message:At Penn State University the Department of Entomomlogy is conducting research on honey bees.  Researchers and students study behavior and diseases.  Swarms, viruses, immune systems, and controling disease are some of the specific things that are being studied. The website is http://beelab.cas.psu.edu/research.html/
=========yorg=========
===from:Nichole Kayser
===date:Fri Nov  9 15:12:47 2001
===subject:invertebrate research
===message:Many invertebrate studies are being done in the LRSC.  This article focuses a lot on the primary periods and secondary periods of productivity and food sources.  They study the seasonal growth rates of caddisfly larvae.  Controlling their food souce and also the environments in which they live.  

The address is:  http://bio.winona.msus.edu/delong/invertebrate_studies.htm
=========yorg=========
===from:Jennifer Swenson
===date:Fri Nov  9 16:57:27 2001
===subject:Assignment #8
===message:I found research on jellyfish and their affect on the Chesapeake Bay region.  It can be found at http://www.mdsg.umd.edu/MaineNotes/Jul-Aug94.  It discusses the research of Ed Houde from Chesapeake Biological Lab and how the large numbers of sea nettle jellyfish maybe connected to the amount of larger numbers of phytoplankton found in the Chesapeake Bay.  It also discusses several other alternatives to why there seems to be such an increase in the nettles during the summer.
=========yorg=========
===from:Carrie Sanneman
===date:Fri Nov  9 18:25:52 2001
===subject:invertebrate research web site
===message:http://www.dmns.org/denverbasin2/fossil/invertres.html
=========yorg=========
===from:Carrie Sanneman
===date:Fri Nov  9 18:33:00 2001
===subject:Summary of web site
===message:I forgot the summary on my last posting. The site is  - http://www.dmns.org/denverbasin2/fossil/invertres.html
It is about the giant ammonite, which is an ancient relative to the squid, octopus, and nautalis.  The walls of the chambers within the ammonite were corrugated, making it stronger and lighter, and required less calcium to grow, so the organism could grow faster.  The ammonites were sexually dimorphic.  The researchers are still looking into why the fossils are found left side up and what happened after their extinction to cause this.
=========yorg=========
===from:Henry Alliger
===institution_site:http://www.nih.gov/science/models/c_elegans/
===institution:C. elegans
===date:Fri Nov  9 18:41:29 2001
===subject:assignment 8
===message:www.nih.gov/science/models/c_elegans/
This site has links to a varitety of sites about invertibrates.  One of the links has a site for a continueing project and has daily updates.  Other links take you to Center for Desease Control (CDC) pages about pathalogical roundworms.  I didn't take the time to look at all the links, but the ones I did look at were interesting.
=========yorg=========
===from:Tyler Haupt
===email:tyhaupt@iastate.edu
===institution_site:http://www. amap.no/assess/soaer4.htm
===institution:Arctic Polar
===date:Fri Nov  9 19:15:24 2001
===subject:Assignment 8
===message:This research article is about the polar conditions of the arctic. Within this article is extensive research on ecology of the arctic world which contains the invertabrates of polar situations. This is a very informational article which is definetly worth the time to read it.
=========yorg=========
===from:Chelcee Jolee Hindman
===institution_site:http://www.research.mdsg.umd.edu/FMPro?-db=funded%5fresearch&-format=record%5fdetail.htm&-lay=pat&-sortfield=Year&-sortfield=PATPortfolio&-sortfield=PILast&-op=cn&keyword%5fsearch=invertebrates&-max=20&-recid=33271&-find=
===institution:University of Maryland Biotechnology Institute Center for Marine Biotechnology 
===date:Fri Nov  9 19:20:50 2001
===subject:Assignment #8
===message:This is a molecular approach to environment studies on Perkinsus marinus. Transmission dynamics of infection in Chesapeake Bay.This website is focused on continuing the application of the quantitative molecular (PCR) diagnostic techniques for practical field purposes regarding the etiology (which is all of the causes of a disease or abnormal condition) of an oyster disease in the Chesapeake Bay.  The Maryland Sea Grant's long term goals are to develop molecular approaches for the specific and sensitive assessment of P. marinus and Perkinsus species in order to understand the the causes of this oyster disease in the Chesapeake Bay. Current critical questions regarding P. marinus infections revolve around the ability to quantify low-levels of the parasite in hatcheries and the environment. The presence of multiple strains of P. marinus with various levels of virulence and other Perkinsus species that are positive with FTM assays further complicates the situation.  It also causes a serious problem in the assessment of P. marinus infections in natural oyster populations and farmed stocks. It is very important for the Maryland See Grant to discriminate between virulent and avirulent strains or species that they are detecting by FTM analysis.  Discrimination of multiple strains or species of Perkinsus in oysters and accurately assess their role in disease transmission in the environment.  The determination of factors that define virulent vs. avirulent stains or species of Perkinsus is at a molecular level. This is based on selected loci. 
=========yorg=========
===from:Kelsey Paulson
===email:kpaulson@iastate.edu
===institution_site:http://newfoundland.insectarion.net/home.htm
===institution:newfoundland?
===date:Fri Nov  9 19:46:13 2001
===subject:invertebrate research
===message:The webpage I found explained their research on the class insecta. The paleontologists are trying to set up a new phylogenic tree for a type of insect.  A few years ago they found a new type somewhere in Egypt and they now believe it may have preceded other insects in the now recognized tree.
=========yorg=========
===from:Ashley Fletcher
===date:Fri Nov  9 20:03:02 2001
===subject:Invertebrate Research
===message:http://www.sfu.ca/~fankbone/r/rsrintrs.html
This website talks about 25 years of research done by a man who is questioning how different groups of invertebrates obtain their nutritional requirements.  It also studies the feeding and digestive mechanisms within different phyla.
=========yorg=========
===from:Jen Smolley
===date:Fri Nov  9 20:16:37 2001
===subject:assignment # 8
===message:I looked at a website that documents research on Veliger larva.  The website is located at http://www.auburn.edu/academic/science_math/zoology/veliger.html.  It describes research on the veliger larva's nervous system.  The site has labeled diagrams and pictures.  It describes what a larva really is, and contains definitions for the developmental stages of life.  The site is based on the research of Steve Kempf at Auburn University.  
=========yorg=========
===from:John Loy
===date:Fri Nov  9 20:47:44 2001
===subject:Invertebrate Research
===message:My research article is from the Victorian Institute of Invertebrate Research http://www.insectonline.com/ecc.html 
They did research concerning nutrient levels in the soil and the amount of microinvertebrates and how they affected it.  The institute undertook recent studies of the Victorian Northern plains and found that the loss of invertebrate detritivores (decomposing invertebrates) may inhibit the release of nutrients into the nutrient poor soil types of the ecosystem .
=========yorg=========
===from:Jonathan Turner
===date:Fri Nov  9 23:17:35 2001
===subject:Invertebrate Research
===message:http://www.darwinfoundation.org/articles/br15049805.html

This site has information from three different studies since 1982.  Mainly they just wanted to create an inventory of all terrestrial arthropods on the galapagos islands.They say that before their research there were only 70 spider species and 900 insect species, but because of this research the number has nearly doubled.
=========yorg=========
