===from:Chelcee Hindman
===date:Wed Oct 24  0:38:20 2001
===subject:Extra Credit
===message:Just because an Athiest doesn't believe in God, doesn't mean that he or she doesn't believe that they exist.  In the Bible---James 2:19---"You believe that there is one God.  Good!  Even the deamons beliveve that-and shudder."  Some Athiests DO agree that a Higher Being does exists---the same as the devil does---and "shudder" at the their thinking---and furthermore they may completely dismiss the thought of a Higher Being.  Some Athiests don't want to be a part of any religion--or take sides--so they simply deny the fact or religion.  Others choose to believe that there is no God whatsoever.  But why???  Is it an easy way out?!?
=========yorg=========
