===from:Scott  Schaus
===date:Thu Oct  4 23:24:19 2001
===subject:Tracing evolution
===message:Chelci:

Outstanding insights and questions. You could maybe turn the questions into the creation/evolution discussion with your group. Next Tuesday's lecture (lecture 12) will address some of these questions and issues, so let's see what you think after that lecture.
<br>
Scott
=========yorg=========
