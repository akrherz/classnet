===from:austin wills
===date:Tue Oct 16 21:55:16 2001
===subject:evolution vs. creationism
===message:Our group failed coordinate a meeting between all of us.
This is my view. The world has many different religions. There are probably as many different creation view as there are religions. Many creationists believe that God created, earth, the life forms on earth, and the universe surrounding us in 7 days. They also believe that this all happened less than 10,000 years ago. Only minor changes with in various species have occurred since creation, no new species have evolved or been created. 
Evolutionists believe the origin of the universe happened between 10 and 20 billion years ago. The earth came to be approximately 4.5 billion years ago. Life began, probably as bacteria and has been evolving ever since. Natural forces have driven the process of evolution without any input from a God or Goddess.
Both creationists and evolutionist�s believe in some form of mass extinction. The bible states that this occurred in the story of Noah�s Ark. If this is true, where did all the water come from? Where did all the water go? The bibl also states that grasses, trees, and other land plants were created prior to the sun. If this is so, how do we explain such things as photosynthesis? 
Because no human was able to observe the earth being formed and record the processes that occurred, it is impossible to prove that the earth really is billions of years old, or that the earth, its elements and animals were made from a celestial being. I feel that evolution is the more probable idea. However, the creationist view does help to fill in some of the holes in the evolutionist view, such as helping to explain the absence of transitional fossils.


=========yorg=========
