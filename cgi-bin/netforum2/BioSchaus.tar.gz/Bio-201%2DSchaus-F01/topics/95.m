===from:Neddy
===email:ntl0812@iastate.edu
===date:Tue Oct 23 15:13:46 2001
===subject:Perfection reply
===message:I'm not sure why the eye isn't perfect, but he was saying that evolutionits contradict themselves.  First they say the eye itsn't perfect and that God would have made it perfect if he was real and then they say that there is no way to make the eye perfect.  I hope that helps.
=========yorg=========
