===psite:http://research.amnh.org/
===from:Mariah Porter
===institution:http://research.amnh.org/invertzoo/research.html
===date:Thu Nov  8 21:44:36 2001
===subject:second posting of link
===message:I didnt know if I was one that had to e post so I am doing it anyway. The new website in from the natural history museum's reseach page. If you go here you can get there latest research on any and all invertebrats known to man

=========yorg=========
