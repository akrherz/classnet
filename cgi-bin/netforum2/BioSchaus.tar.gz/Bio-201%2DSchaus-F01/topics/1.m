===from:Scott Schaus 
===institution:Iowa State University
===date:Tue Aug 28 11:05:33 2001
===subject:My Introduction
===message:I'm originally from Akron, OH. I'm finishing my doctorate in Eric Henderson's lab, where I study cellular signal transduction using atomic force microscopy and fluorescence microscopy.

I've particpated in most sports (except football) over my lifetime, and coached high school soccer for 10 years. My current "obsession" is learning to play inline hockey, but I started way too late!!

I play bass guitar on a local church music team, and have played in a couple of bands in the area, but none currently.

I've taught biology and life sciences at all levels, from high school general biology, to graduate physiology. I'm looking forward to teaching General Biology at the college level this year. It'll be a nice change from upper level courses.

See you in next lecture.

Scott

=========yorg=========
===from:Jeff Anderson
===date:Tue Aug 28 14:26:07 2001
===subject:My interests
===message:I am currently a sophmore here at Iowa state.  I grew up in Illionis and was raised on a farm.  I showed cattle and hogs this past year and did pretty well.  I really enjoy animals and biology.  hopefully this is fun amd easy.
=========yorg=========
===from:Janessa Christensen
===email:jchriste@iastate.edu
===date:Tue Aug 28 14:28:12 2001
===subject:Introduction
===message:hi everybody in bio 201 my name is janessa christensen and i am from spencer iowa.  it is a town of about 12,000 in northwest iowa.  i enjoy music, tennis and writing.  i am taking this class because i really enjoy science and i am planning on going on to vet school after i get my degree in animal science.  i grew up on a farm and i'm really interested in working in the agricultural community.
=========yorg=========
===from:Sharon Brown
===email:scbrown@iastate.edu
===date:Tue Aug 28 14:29:44 2001
===subject:Introduction
===message:My name is Sharon Brown.  I am an 18-year-old freshman majoring in Animal Science/prevet.  My hometown is Oregon, IL.  My main two sports in high school were cross country and track.  I akso enjoy swimming, water skiing, and most other sporting activities.  I am a seven year 4-H member in Ogle County and have a strong agricultural background.  I am looking forward to Biology 201 this semester.
=========yorg=========
===from:Tyler Lewis
===date:Tue Aug 28 14:43:29 2001
===subject:Intro
===message:Hi everyone.. My name is Tyler Lewis.. I am from Council Bluffs, Ia.. I ran cross-country and track in high school.. I am double majoring in Forestry and Horticulture.. I am looking forward to bio because it was always interesting in high school.. 
=========yorg=========
===from:Ashlie Mcwee
===date:Tue Aug 28 14:51:03 2001
===subject:Bio201
===message:Hello to all fellow classmates, 
my name is Ashlie Mcwee. I hail from the Mile High City. Denver, Colorado. I have the luxury of attending I.S.U. On a volleyball scholarship. I'm currently a freshman (obviously!) majoring in Sports Medicine. If you see me around, don't hesitate to holla.
=========yorg=========
===from:Henry
===date:Tue Aug 28 15:17:26 2001
===subject:Intro
===message:Just wanted to say hi.  Fact about myself, I have owned a company since I was 14.  I have also always wanted to come to ISU.  
=========yorg=========
===from:Paul Reicks
===date:Tue Aug 28 15:25:24 2001
===subject:Bio 201
===message:Hi,  I am from Lawler, Iowa.  I am going to ISU for Agronomy.  I like hunting and fishing.
=========yorg=========
===from:Chelsi Cervetti
===email:Cheltzy@hotmail.com
===date:Tue Aug 28 15:43:57 2001
===subject:A little about me
===message:Hi, Im Chelsi.  Im a Freshman this year and Iowa State is a big change for me.  I graduated from small Christain academy in Waterloo Ia. with my class of 36 kids. As far as hobbies go, I run, I'm into art, and I love doing out-doorsy stuff.  This summer my sister's and I went out to Colorado to do some climbing and backpacking. We only got lost once; it was a good trip!

=========yorg=========
===from:LeAnn Kacmarynski
===email:leannkac@iastate.com
===date:Tue Aug 28 15:59:08 2001
===subject:About me
===message:I am LeAnn.  I come from a Northwest Iowa town of around 100 people or less.  I am in Animal Ecology.  I also love the outdoors and meeting new people.  
=========yorg=========
===from:Ben Fleming
===date:Tue Aug 28 16:16:17 2001
===subject:My Introduction
===message:Hello!  My name is Ben Fleming.  I am from Davenport, Iowa and am a freshman this year. I did Cross Country and track in high school and hope to motivate myself enough to continue to run!  As of yet, I do not have a major selected.  I am interested in Biology, so maybe this class will help me decide!  See you all later.

Ben  
=========yorg=========
===from:Brent Thompson
===date:Tue Aug 28 16:48:15 2001
===subject:Biology 201
===message:Hi.  My name is Brent Thompson.  I come from North Central Iowa.  I have lived on a farm ever since I was born.  I enjoy working with livestock, hunting, riding 4-wheelers and motorcycles and I like hanging out with friends.  My major is Agriculture undeclared.  I would like to meet all of you.

Brent
=========yorg=========
===from:Jennifer Swenson
===date:Tue Aug 28 17:10:56 2001
===subject:Biology 201
===message:My name is Jennifer Swenson and I am a re-entering senior in Animal Ecology.  I am from the Ames area and working on my second degree.  My favorite past times are spending time outside with my many pets and with my friends and family.
   
=========yorg=========
===from:Kristin Burdorf
===email:kburdorf@iastate.edu
===date:Tue Aug 28 17:16:24 2001
===subject:This is me
===message:Hey everyone!!!  I'm from Mundelein, Il, it's about 45 min. north of Chicago.  I have a younger brother and two cats.  I'm majoring in Vet Med with an emphasis on Wildlife and Aquatic.  I plan to work in a zoo when I graduate in a nice warm climate.  I'm not one for the winter.  Im taking Biology 201 to fill a requirement and because I enjoy the class.  I've taken two full years of Biology in high school, and I'm very friendly so if you need help or just want to hang out I'm in room 1311 Wallace Kilbourne over in the Towers.  I hope to see all of you around campus and I hope you all have a great year. 
=========yorg=========
===from:Katie McQuillan
===email:kmcquill@iastate.edu
===date:Tue Aug 28 18:19:12 2001
===subject:Introduction
===message:Hey everyone!  I'm Katie McQuillan and I am a freshman here.  I am from Eden Prairie, MN.  I have two brothers and I love to dance.  I'm currently a psych major, but I'm planning to change.  I'm living out in towers and I'm taking biology to learn more about it.  I'm looking forward to meeting everyone and having a good time!
=========yorg=========
===from:Katie Sprinkle
===date:Tue Aug 28 18:22:09 2001
===subject:Wow!
===message:Hey! My name is Katie Sprinkle and I am from Rockford, Illinois.  It is the second biggest city in Illinois.  I have never met so many people who live on farms or are from small towns untill I came to Iowa.  These introductions have been beyond entertaining.  I hope to get to know all of you better. Have a great day!  
=========yorg=========
===from:Jill
===date:Tue Aug 28 18:59:37 2001
===subject:Eggers
===message:I am originally from State Center, IA.  I graduated from West Marshall High school in a class of 69.  I was involved in all kinds of activities but my favorites were basketball where I was all-state 3 years and a scholastic all-american and track where I went to state 3 years in discus and finally won class 2A last year even while undergoing treatments for cancer, which I have been done with for one week.  I chose Iowa State because I love their campus and all my family has gone here.
=========yorg=========
===from:Lena Pelzer
===email:apelzer@iastate.edu
===date:Tue Aug 28 19:04:09 2001
===subject:Hey everyone
===message:Hi everyone.  my name is Lena Pelzer, i'm a freshman, i live in willow and i'm from iowa city.  i've taken two years of biology before and enjoy the class but i don't have a major yet.  i'm here to have fun and meet people.
=========yorg=========
===from:Sue Min
===email:smmin@iastate.edu
===date:Tue Aug 28 19:04:15 2001
===subject:Hi!
===message:Hi!  I am Sue Min.  I am from Woodstock, Illinois.  It is a town about 45 miles northwest of Chicago.  It is also the town that the movie Groundhog Day was filmed in.  Yeah, I know that is lame, but it is my towns only claim to fame.  Well, that and Dick Tracy, but anyways...I am currently a zoology major and I am taking Biology b/c it is a requirement and I enjoy the class.  I am living in Oak Fosmark and yes, I am a freshman.  Well, I don't have much else to write...so I hope you all have a lovely day and I am looking forward to meeting you.
=========yorg=========
===from:Chris Penne
===date:Tue Aug 28 19:13:54 2001
===subject:INTRODUCTION
===message:Hello everyone,                                            
I am a junior who just transferred from the University of Iowa to take up a major in Animal Ecology and I hail from Newton, Iowa.
=========yorg=========
===from:Jonathan Turner
===date:Tue Aug 28 19:20:34 2001
===subject:Biology
===message:Hows it goin class, I'm Jonathan Turner.  I'm a freshman here and going through the pre-dental program so hopefully i do well in this class.  I don't know what all you want to know but i'll jsut write some stuff, if it sucks, stop reading.  I'm an avid skiier, love ice hockey, and hanging around with my friends and very beautiful girlfriend of 2 years.  My main hobby though is working on cars, mostly imports.  If you have seen Fast and the Furious, thats basically me in a nutshell.  Well, i hope everyone enjoys the class and does well, and same goes for me.  Later  Jonny
=========yorg=========
===from:Megan Beattie
===email:mbeattie@iastate.edu
===date:Tue Aug 28 19:22:36 2001
===subject:A little about me...
===message:Well hi there fellow Biology 201 people.  My name is Megan and I'm from the tiny town of Treynor, IA (43 in my graduating class).  Treynor is actually about 10 miles from the Council Bluffs, IA/Omaha, NE area.  In high school, I was in everything I could be in.  I chose Iowa State because of the friendly atmosphere.  I am a very outgoing person so I love it here.  Right now, I am undeclared, but I am really thinking about a Biology or Zoology major.  Well, that's about it for me... like I said, I love meeting people so stop by 2316 Wallace Rambo (Towers 2nd floor) anytime... the door is always open, but my roommate's name is also Megan so if you want to talk to me, specify that, if not, no big deal... my roommate is as outgoing as I am!  See you all later!  
=========yorg=========
===from:Kellen Ludvigson
===date:Tue Aug 28 19:27:53 2001
===subject:Go Cyclones
===message:My name is Kellen Ludvigson.  I am from a small town in northwest Iowa called Cushing.  I am a first year student in Animal Science-Pre Vet.  I only took one year of biology in highschool, so this may be a struggle.  I am a member of the AGR frat. 
=========yorg=========
===from:Krista Williams
===email:Snoopie267@aol.com
===date:Tue Aug 28 19:45:52 2001
===subject:About Me
===message:Hi, I'm Krista. I'm from Bolingbrook, IL. It's about 30
miles south of Chicago. My major is Animal Science-Pre-Vet.
I hope to someday work with large animals in a wildlife
preserve or a zoo. I have one younger brother that is a
senior in high school. I've been playing softball for about
12 years in the community league at home, and i'm really
looking forward to joining a team here at school.  
=========yorg=========
===from:Michelle Moutray
===email:mmoutray@iastate.edu
===date:Tue Aug 28 19:51:27 2001
===subject:Bio 201
===message:Hi my name is Michelle Moutray and I am from a small town in Illinois called Sugar Grove. It is located 40 miles west of Chicago. I am a sophomore this year and taking biology because I need a science course. My major is hotel, restaurant, institution management. Hopefully one day I want to be managing a hotel in a warm tourist attraction area.
=========yorg=========
===from:Eric Giebelstein
===email:egiebels@iastate.edu
===date:Tue Aug 28 20:17:32 2001
===subject:bio 201
===message:Hi my name is Eric. I'm from Blue Grass, IA which is near Davenport.  I'm a freshman, I haven't decided what to major in yet but I was thinking Forestry which is why I took this course.  I want to be a forest ranger or a park ranger so I'm hoping that a Forestry major will get me there.
=========yorg=========
===from:Karla Horihan
===email:khorihan@iastate.edu
===date:Tue Aug 28 20:52:36 2001
===subject:About me
===message:Hi there!  I am a freshman here at ISU and am very interested in agriculture.  I was raised on a farm where my dad is running around 3,000 acres.  I live 15 miles north of Decorah, IA called Mabel, MN.  This past summer I worked for the local coop.  If you want to know more about me, look me up. 
=========yorg=========
===from:Heather Williams
===email:hwilliam@iastate.edu
===date:Tue Aug 28 20:53:42 2001
===subject:Introduction
===message:Hi!  My name is Heather Williams and I'm a freshmen.  I am from Boone, Iowa.  I'm currently a Biology major, and I'm thinking of minoring in Psychology.  I love animals and I want to be a veterinarian.
=========yorg=========
===from:Renee Steffens
===date:Tue Aug 28 21:13:37 2001
===subject:More than you want to know...
===message:Hey!  I'm Renee Steffens from Cedar Falls, IA and I am currently majoring in Food Science.  I live in Oak-Elm and I'm excited for this year and its excitement!  Good luck to all!
=========yorg=========
===from:Dan Madsen
===email:dmadsen3@iastate.edu
===date:Tue Aug 28 21:51:06 2001
===subject:info
===message:hello everyone my name is dan madsen. i am from audubon iowa a small town in southwest iowa.  i live on a farm and enjoy rodeo, hunting, working with cattle and horses, and just about any other outdoor activity.  my major is animal science.
=========yorg=========
===from:Megan Mielnik
===email:mmielnik@iastate.edu
===date:Wed Aug 29 13:47:26 2001
===subject:Bio 201-Schaus F01
===message:Hi, I am Megan Mielnik and I am a freshman.  I have not declared a major but really want to be a chiropracter.  I love to dance and run.  
=========yorg=========
===from:Aaron Shields
===date:Wed Aug 29 14:10:09 2001
===subject:Introduction
===message:My name is Aaron.  I am originally from West Des Moines, however, I have been living in Arizona and Colorado since I finished with highschool.  I am credited by being a Junior in the AgBus program here.
I am an avid golfer.  I spend the summers caddying for the PGA and have been lucky enough to have had bags in the past like Scott Gump, Nick Faldo, and most recently Brian Wilson at the International tournament in Castle Rock, CO.
=========yorg=========
===from:Heather Hellstrom
===date:Wed Aug 29 14:24:38 2001
===subject:Assign 1: About Me 
===message:My full name is Heather Joy Hellstrom. Iam a soph. here and iam majoring In Exercise Sports Science/ Corporate Fitness & Health. Iam originally from Hoffman Estates Illinois (Subarb of Chicago) and really enjoy it here in this small toen, Ames. I took Bio 201 last semester but dropped it cause of the professor, dont worry Mr. Schaus you seem like a great professor. See you all in class tomorrow!
=========yorg=========
===from:Kayla Schulte
===email:schultek@iastate.edu
===date:Wed Aug 29 14:25:16 2001
===subject:Bio 201
===message:Hi, my name is Kayla Schulte.  I'm from Marengo, which is by the Amana Colonies and Cedar Rapids.  I am the youngest of three.  I'm double majoring in Agronomy and Environmental Science. I have grown up on a farm my entire life and that has influenced my decision for my majors.  In the future I hope to be working for the DNR, a major seed company like Monsanto, or for a local Farmer's Co-op.  Possible after a few years of working I might go into business myself as a crop scout.
=========yorg=========
===from:Blessie Zacharia
===email:blessie@iastate.edu
===date:Wed Aug 29 15:16:10 2001
===subject:about me
===message:I am originally from West Des Moines, which is about 
45 mins from Ames.  I am doing Biology/Pre-Med, and 
maybe a minor in Business.  I like biology, but I don't 
care for chemistry too much.  In my free time I love to 
hang out with friends and go shopping.
=========yorg=========
===from:Stephen Dullea
===email:sdullea@iastate.edu
===date:Wed Aug 29 15:25:27 2001
===subject:The Atypical Introduction
===message:  My name is Stephen Dullea and I am a transfer student from two schools in MN, where I am originally from. I am on my third college, mostly as a result of there being too few attractive females at my previous residences. From what I have seen here in the past year, there is an abundance of beautiful specimens, which means ISU will be stuck with me for about three more years. If someone blurts out a smart assed answer during a lecture, there is a good chance it came from my mouth, as I love to make people laugh and I feel laughing is a necessary means for getting people to go to and stay awake during class. Luckily, Professor Schaus shares my enthusiasm for making class enjoyable, so I probably won't have to worry about getting extradited from ISU. Oh and by the way, I am a Turfgrass(Golf Course Management) Major and a Spanish Minor. 

=========yorg=========
===from:lindsay west
===date:Wed Aug 29 15:49:43 2001
===subject:hi
===message:hows it goin?  :)

i have nothing else to say
=========yorg=========
===from:Justin Hoeppner
===email:jhoepp@iastate.edu
===date:Wed Aug 29 16:17:19 2001
===subject:Introduction
===message:Hi, My name is Justin Hoeppner. I am a transfer student from Kirkwood Community College. My major is Landscape Horticulture. My hometown is Emmetsburg, IA
=========yorg=========
===from:Nichole Kayser
===date:Wed Aug 29 16:35:48 2001
===subject:Tour of Ames
===message:I'm a sophomore that has lived in Ames my whole life.  So here you go on the tour.

West Ames:  Campus, and West Hy-vee.
North Ames : Wal-Mart, the Mall and Cub Foods.
South Ames : K-Mart, bowling alley, batting and mini golf.
East Ames : McFarland Park and Peterson Pitts, and my home.

If you ever get lost......oh wait...you can't.  This is Ames.  



=========yorg=========
===from:Erika Bolin
===email:erikab@iastate.edu
===date:Wed Aug 29 16:42:55 2001
===subject:intro to me
===message:My name, obviously, is Erika Bolin.  I am from a small town in Southwest Iowa by the name of Thurman.  I graduated from Fremont-Mills CDS with a whole 41 other students.  My interests are animals, reading, the internet (computers), and anything fun.  I love the outdoors.  I have 3 dogs, 2 rats, 5 cats, and 1 1/2 turtles...
=========yorg=========
===from:Marie Malan
===email:memalan@iastate.edu
===date:Wed Aug 29 20:30:20 2001
===subject:About me
===message:My name is Marie and I'm from Marshall, Missouri. I'm a psychology/pre-optometry major, but I think the psychology part of that is going to change soon, because it's just not for me.  This is my second year at ISU and also my second year at Towers.  Only this year I get the pleasure of staying in the newly renovated Wilson Hall, which is cool, but I'm not sure if it's worth the extra money.  I'm sure I'll be cursing it when I have to start paying back loans.
=========yorg=========
===from:Eric Boulommavong
===date:Wed Aug 29 20:41:18 2001
===subject:About me
===message:I'm a biology major here at Iowa State and I'm from 
Storm Lake Iowa.  I come from a town of 10,000 so it's 
pretty small.
=========yorg=========
===from:James Shaw
===date:Wed Aug 29 20:51:51 2001
===subject:BIO 201
===message:Hi! My name is James Shaw and Im from St. Charles Illinois.  I enjoy biology, running and drinking.
=========yorg=========
===from:Rebecca Marzen
===date:Wed Aug 29 20:52:53 2001
===subject:About me!
===message:Hi all!  My name's Rebecca (I'm sure you've already figured that much out).  I'm from an extremely small town in northern Iowa.  We're talking population of about 100.  I'm a sophomore here at ISU, majoring in Psychology.  I'm taking Biology as a science requirement.  As soon as I pass out of this class I'll have fulfilled all of my science requirements!  Woo-hoo!
=========yorg=========
===from:Shawn Macha
===date:Wed Aug 29 20:57:40 2001
===subject:about me
===message:My name is Shawn Thomas Macha.  I go as Stiggy--long story. I am from Baxter, Iowa, and I am a freshman.  I am also a pledge at Phi Kappa Theta.  If anyone has any questions about the greek system or intrested in joining please e-mail me at smacha@iastate.edu
                                         Shawn
=========yorg=========
===from:Adam Althoff
===date:Wed Aug 29 20:59:58 2001
===subject:About Me
===message:I'm a freshman majoring in Dairy Science, and I may minor in Ag Business as well.  I from a dairy farm from the small town of LaMotte, Iowa which is just south of Dubuque.  I am majoring in Dairy Science because I love to work with cows, and I especially love to show them at fairs.  The best dairy breed by far is holsteins!  Anything else is just not worth working with!
=========yorg=========
===from:Deanna Greene
===email:dgreene@iastate.edu
===institution:Biology 201
===date:Wed Aug 29 21:03:18 2001
===subject:Hello!
===message:Hi, my name is Deanna Greene.  I live at 6261 Willow Bates.  My phone number is 572-0602.  I am from Prairie City, IA and am a freshman this year.  If you ever get bored feel free to come visit my roomate and I.  See you in biology.
=========yorg=========
===from:Erich Hugunin
===date:Wed Aug 29 21:34:58 2001
===subject:Whats up 
===message:My name as seen above is Erich Hugunin Im soon to be a Sigma
Chi within the next week best house around. Right now i live
in Helser room 1559 mortenson girls feal free to stop in Im
a Forestry major so im goingto be taking alot of science
classes while im here. Im from Bettendorf Iowa, but on the
down side my parents just move to some tiny as town Called
Camanche.
=========yorg=========
===from:Gjert Skaar
===email:el_barefoot_diablo@hotmail.com
===date:Wed Aug 29 23:01:02 2001
===subject:Jello! er..Hello
===message:Ok, so I'm this guy from Marshalltown.  Thats in Iowa, I think.  I'm a junior in journalism and mass comm.  My name is odd, I know.  I'm not a foreign exchange student or anything, I just have a Norwegian name.  I'm 21 years old(Wahoo4bars) until I turn 22 in November.  Anything I forgot?


=========yorg=========
===from:Gina Shook
===email:genie713@iastate.edu
===date:Wed Aug 29 23:03:51 2001
===subject:Biology 201
===message:Hi!  This is Gina.  I'm a freshman here at ISU, and am probably one of a very few biology majors in this non-major class (it just fit better into my schedule).  I am planning on attending medical school after this, and practicing radiology.
I really love to sing, and just joined Lyrica, one of ISU's choirs.  As far as dislikes go............chemistry!  It's so time consuming.  Which means I should probably get back to that, so bye for now!
=========yorg=========
===from:Chris Olsem
===email:olsem@iastate.edu
===date:Thu Aug 30  9:28:24 2001
===subject:Biology 201
===message:Hi my name is Chris Olsem, I am from Greeley, Ia, a town of about 100 people (60 miles north of cedar rapids) i graduated from edgewood-colesburg high school this spring
  currently i am undelcared in the college of ag, and lookiing at ag engineering, AST, or animal science for a major
  i like biology class and i am looking forward to it
=========yorg=========
===from:Krista Burich
===email:kburich@iastate.edu
===date:Thu Aug 30 10:15:12 2001
===subject:Hello!
===message:Hi, my name is Krista and I'm a sophmore at Iowa State.  I enjoy riding horses, foxhunting, and playing sports.  I am hoping to have a great fall semester.
=========yorg=========
===from:Art Holle
===email:aholle@iastate.edu
===institution:ISU
===date:Thu Aug 30 10:57:03 2001
===subject:Biology 201
===message:My name is Art Holle.  I am from Guthrie Center, Iowa.  I don't know what I am going to major in yet.
=========yorg=========
===from:Jessica Eriksen
===date:Thu Aug 30 14:38:46 2001
===subject:Biology 201
===message:Hi my name is Jessica Eriksen...I am a sophmore in Pre-occupational therapy and Finance.  I am from Blair, Nebraska..which is about 20 minutes away from Omaha.  I am 18 years old and am super excited because on Monday (labor day) we don't have school and it is my Birthday!!!  I am probably the youngest sophmore in college there is..oh well!!

=========yorg=========
===from:Tina Meger
===date:Thu Aug 30 14:42:15 2001
===subject:hi to everybody
===message:Hey-this is Tina. I am a freshman at ISU. I am from Minnesota, and just for clarification I DO NOT talk funny. I have been told that ever since I got here. Anyway-I am majoring in Exercise and Sport Science, and hope to be a pediatric physical therapist some day. Best of luck to all of you with your classes, and I hope to get to know many of you this semester or sometime in the future.
=========yorg=========
===from:Jamie Moran
===date:Thu Aug 30 14:46:54 2001
===subject:Biology 201
===message:I'm Jamie. I'm unofficially a sophomore (2 credits short)from Fremont, Nebraska.  I took half of this class last semester with a different teacher but had to drop it so maybe I'll be a little ahead.  My major is Business and I am taking Pre-med classes to see how it goes.  That's all for now! 
=========yorg=========
===from:Jamie Moran
===institution:Iowa State University
===date:Thu Aug 30 14:48:48 2001
===subject:Biology 201
===message:I'm Jamie. I'm unofficially a sophomore (2 credits short)from Fremont, Nebraska.  I took half of this class last semester with a different teacher but had to drop it so maybe I'll be a little ahead.  My major is Business and I am taking Pre-med classes to see how it goes.  That's all for now! 
=========yorg=========
===from:Ross Meade
===date:Thu Aug 30 14:59:02 2001
===subject:Biology is so Fun!
===message:My name is Ross Meade.  I am from Council Bluffs, IA.  I am a senior here at Iowa State and will graduate in December of 2002, with a degree in Agricultural Systems Technology.  I consider myself a Fun_gi.
=========yorg=========
===from:Ryan Schlater
===email:Ryeride@iastate.edu
===date:Thu Aug 30 15:13:08 2001
===subject:Bio Introduction
===message:Hi my name is Ryan Schlater.  I'm from Carroll, IA.  My major is Animal Ecology. 
=========yorg=========
===from:Scott Carlson
===date:Thu Aug 30 15:15:14 2001
===subject:hey
===message:  My name is Scott Carlson.  I am a senior in psychology from Fort Dodge Ia.
=========yorg=========
===from:tyson comer
===date:Thu Aug 30 15:18:12 2001
===subject:great class
===message:bio is fun

=========yorg=========
===from:Pam Haluska
===email:phaluska@iastate.edu
===date:Thu Aug 30 15:27:15 2001
===subject:Bio 201
===message:Hello! My name is Pam and I am from Jefferson, Iowa.  I am a freshman and majoring in Nursing.
=========yorg=========
===from:Jaime Kutcher
===date:Thu Aug 30 15:30:53 2001
===subject:Biology 201
===message:Hi, my name is Jaime.  Right now I am a landscape architecture major with thoughts of switching to Horticulture.  I am not that fond of the College of Design. This is my second attempt at Bio 201, I dropped it last year.  I had Biology in highschool but I graduated back in 1994 and dropped out of college in 1995.  Coming back to college is a challenge but offers a lot more freedom (and opportunity) than working full-time.  I love to travel and hope that I can pass Biology this time around.
=========yorg=========
===from:Stephanie Triggs
===email:striggs@iastate.edu
===date:Thu Aug 30 15:36:40 2001
===subject:Bio 201
===message:Hey there!  My name is Stephanie Triggs and I am a freshmen from Mt. Vernon, IA, a small town east of Cedar Rapids.  I've been involved with a lot of different organizations in the past.  Some of which include volleyball, tennis, student council, and FCA.  
As for my future at ISU, I plan on double majoring in Excercise Science and Dietetics.
=========yorg=========
===from:Chiew-Ling Chia
===email:chiewl@iastate.edu
===date:Thu Aug 30 15:47:52 2001
===subject:Bio 201
===message:Hi,
    I'm Chiew-Ling. I'm a transfer student from Malaysia. 
This is my first time in US. My major is Food Science 
and Bio 201 is a required subject for me in order to 
proceed my FSHN subjects. I hope that all of us in this 
class can work together and pass the subject with 
excellent grade. Lastly, nice meeting all of you.  
=========yorg=========
===from:JJ Steuk
===date:Thu Aug 30 15:51:17 2001
===subject:bio 201
===message:hi I m a freshman from Denison Iowa, I am majoring in Agronomy. I have always been around farming and was involved with FFA in high school.
=========yorg=========
===from:Baron
===date:Thu Aug 30 15:53:42 2001
===subject:Bio 201
===message:My name is Baron Bjore I'm from Wahpeton, ND. I'm a freshman Gen-prevet student.
=========yorg=========
===from:Tyler Haupt
===email:tyhaupt@iastate.edu
===date:Thu Aug 30 15:56:44 2001
===subject:Biology 201
===message:Hey what's up. My name is Tyler Haupt from Clarion, Iowa. I am a freshman majoring in Agronomy. Not real sure on where the degree will take me. I'm livin out in Towers, on the coolest floor, 4th floor co-ed. I enjoy all sports, either playing them or watching them. I think Biology is going to be a tough class for me, so if anyone wants to study together write me.  
=========yorg=========
===from:Lana Meyer
===email:lana1916@iastate.edu
===date:Thu Aug 30 16:07:49 2001
===subject:Biology201
===message:Hey there,  My name is Lana Meyer, and I am from 
Hudson, Iowa.  I am an open major in the college of 
Liberal Arts and Sciences, and living in Friley.  I love to 
go to the rec a lot and am looking forward to all the 
intrumurals.  I am done everyday with classes by 2 and 
it is great, but I have a terrible procrastination problem 
when it comes to homework.  ;)
=========yorg=========
===from:Lizzie Burt
===date:Thu Aug 30 16:21:02 2001
===subject:Hey guys
===message:Hi everyone --->
My name is Lizzie, and I'm a transfer student from Cornell College in Mt. Vernon.  If anyone is looking for a vacation option come spring break, I highly advise staying as far away from Mt. Vernon as possible :)    I am a dietetics major and spend most of my free time running or walking. (I'm really cool like that.)
=========yorg=========
===from:Lizzie Burt
===date:Thu Aug 30 16:21:13 2001
===subject:Hey guys
===message:Hi everyone --->
My name is Lizzie, and I'm a transfer student from Cornell College in Mt. Vernon.  If anyone is looking for a vacation option come spring break, I highly advise staying as far away from Mt. Vernon as possible :)    I am a dietetics major and spend most of my free time running or walking. (I'm really cool like that.)
=========yorg=========
===from:Ben Drescher
===date:Thu Aug 30 16:30:55 2001
===subject:about me
===message:hello every one in bio 201 I am an Ag major and I am from Alden Minnesota the corn looks good down here. I would say it is about 2-3 weeks a head of ours. you guys have a little warmer weather too  
=========yorg=========
===from:Ashley Fletcher
===email:afletch@iastate.edu
===date:Thu Aug 30 16:44:19 2001
===subject:Hey
===message:I'm from Sgt. Bluff, IA.  It's right outside of Sioux City.  I am planning to go into a health care profession, but I am still undecided about what I want to specialize in.
=========yorg=========
===from:Anthony Ebel
===email:tonyebel@yahoo.com
===date:Thu Aug 30 17:13:29 2001
===subject:Biol 201
===message:Hey,

My name is Anthony Ebel, usually called Tony of course.  I grew up in a small town, Paullina, in NW Iowa.   I played baseball at the University of Nebraska-Omaha last year before transfering here as a sophomore.  I spend a lot of time playing sports, working out, chillin with friends and plenty of partying.  I am a genetics major and hope to go on to Palmer West Chiropractic College in San Jose, CA.
=========yorg=========
===from:Carolyn Mellmann
===date:Thu Aug 30 18:08:26 2001
===subject:Intorduction
===message:Hello, I am a 5th year senior here at ISU.  I am planning on graduating next August with a degree in Community Health Education.  I am 22 years old, I have a husbond that is also here at ISU.  I like fishing, gardening, and eating.  Someday I hope to make a carrier of them.  Until then, I hope to work with retiriment aged people teaching them how to stay active and healthy for longer and better quality lives.  

=========yorg=========
===from:Lora Reznikov
===date:Thu Aug 30 18:11:08 2001
===subject:Biology 201
===message:Hey, my name is Lora Reznikov. I'm from LeMars, IA, which is about 3 hours away from here. So far, I like Iowa State. My sister is a senior here this year, so that's fun. I am the baby of the family, I have two older brothers, an older sister, and a step-brother and step-sister. I'm undecided on my major right now...maybe music therapy? Anyway, bio is one of the classes I actually don't mind going to and I hope it stays that way!
=========yorg=========
===from:Dana Jones
===date:Thu Aug 30 18:16:32 2001
===subject:Hey all you bio fans!
===message:Hi, my name is Dana Jones.  I am from Nevada, IA, which is a ten minute drive from here.  My major is Animal Ecology Pre-Vet, in the College of Agriculture.  I hope to someday be a vet at a major zoo, but if that doesn't work out I will be the Crocodile Hunter's new partner.  Steve Erwin is my hero, and I hope some of you share my thoughts on him.  I am looking forward to a fun filled semester of Biology!!
=========yorg=========
===from:Dana Jones
===date:Thu Aug 30 18:18:12 2001
===subject:Hey all you bio fans!
===message:Hi, my name is Dana Jones.  I am a freshmen, and I live in temp housing in Knapp.  I am from Nevada, IA, which is a ten minute drive from here.  My major is Animal Ecology Pre-Vet, in the College of Agriculture.  I hope to someday be a vet at a major zoo, but if that doesn't work out I will be the Crocodile Hunter's new partner.  Steve Erwin is my hero, and I hope some of you share my thoughts on him.  I am looking forward to a fun filled semester of Biology!!
=========yorg=========
===from:Freda Perry
===date:Thu Aug 30 18:40:06 2001
===subject:Introduction
===message:Hey everyone!
 
	My name is Freda and I am from good old San Antonio, Texas.  I was born in Manila, Philippenes and can understand the filipino language (also known as tagalog).  I am here at Iowa St. on an academic scholarship, but I still do not know why I choose this school. Even though Iowa weather is definately a change from Texas weather, I am looking foward towards some snow.  
	I plan to become a pre-med major, either going into the school of physical therapy or dentistry.  Nonetheless, I want to become a doctor of some sort.  So I guess it is safe to say that taking this Bio class is a "must".
=========yorg=========
===from:Derek Smith
===email:dereksmith80@hotmail.com
===date:Thu Aug 30 18:51:15 2001
===subject:Biology 201
===message:Hello,
    My name is Derek Smith.  I am a junior animal science student and reside from Hawkeye, in the NE corner of the state.  When done with school I will be returning home to take over the family farming operation.

=========yorg=========
===from:Brian Brand
===email:bbrand@iastate.edu
===date:Thu Aug 30 18:54:04 2001
===subject:Hello Biology
===message:Hi, my name is Brian Brand.  I am a freshman studying agronomy.  I live on fourth floor of Knapp.  My home is on a farm outside of West Liberty, Iowa just southeast of Iowa City.  I hope that the year goes well for everyone and have a great Biology class!
=========yorg=========
===from:Beth Zaun
===email:bzaun@iastate.edu
===date:Thu Aug 30 18:58:05 2001
===subject:Biology 201
===message:Hi, I'm Beth Zaun.  I am a freshman studying pre-dentistry.
=========yorg=========
===from:Dulcie Zirnhelt
===email:nator1284@yahoo.com
===date:Thu Aug 30 19:00:22 2001
===subject:Biology 201-About me
===message:I'm not a biology or pre-med or animal science major, but rather a community health major.  I'm taking this class as a requirement and also this is really the only science class I actually like.  I'm a junior and this will be my second year since i transferred from southwest missouri state university and really enjoy it here.  after i graduate i would like to find a job in a corporate company such as plus one health management working as a manager or specialist.
=========yorg=========
===from:Pat Hoffmann
===date:Thu Aug 30 19:03:04 2001
===subject:Bio201
===message:My name is Pat Hoffmann and I am an animal science/pre-vet major.  Biology is a great interest to me because I can easily relate to it. I hope class stays interesting and not to hard.
=========yorg=========
===from:Melissa Winter
===date:Thu Aug 30 19:28:52 2001
===subject:Biology 201
===message:Hi! I am completely undecided about what I want to be "when I grow up."  One of the many things I've considered is marine biology. But I'm taking many different classes to see what interests me. 
=========yorg=========
===from:Hillary Vogt
===date:Thu Aug 30 19:38:01 2001
===subject:Biology 201
===message:Hey everyone, I'm a freshman majoring in biology.  I'm not really sure what I want do to as a career, so i'm just exploring different options.  I took biology and anatomy and physiology in high school and I loved both classes.  Hopefully I'll pursue a career in the biology field.  

=========yorg=========
===from:Tonya Ruddick
===email:truddick@iastate.edu
===date:Thu Aug 30 20:21:14 2001
===subject:myself
===message:Hi! My name is Tonya Ruddick and I am a sophmore with an undecided major. I am from Huxley, IA, about 10 minutes south of here.  I am scientifically handicapped, so I'm kind of nervous about this class.
=========yorg=========
===from:Caleb Bergmann
===date:Thu Aug 30 20:52:41 2001
===subject:bio201
===message:I am Caleb Bergmann.  I am from Waverly IA and I am majoring in ag studies. I took a simmilar class in high school that used this book and went rather in depth on several different ocasions
=========yorg=========
===from:Heather Wamsley
===email:hea927
===date:Thu Aug 30 20:59:29 2001
===subject:all about me
===message:Hello all~ my name is Heather. I'm a freshman here at ISU majoring in animal science and living in friley-palmer. I'm from Davenport, Iowa about 3 hours southeast of here.  Just a little tid bit of my life....My friends all call me hea because we are all bowlers and when you put my name in the machine, hea is what comes up so it kinda stuck. Kinda dorky but it's cute!!! just thought you'd like to know!;) Good luck this semester in biology!
=========yorg=========
===from:Kevin
===date:Thu Aug 30 21:07:20 2001
===subject:intro
===message:My name is kevin kasper. I am from ankeny, IA.  I like to spend my time hanging out with friends and playing sports like dics golf. My Major is undecided.
=========yorg=========
===from:Mariah Porter
===email:Mcporter@iastate.edu
===date:Thu Aug 30 22:12:10 2001
===subject:Who am I
===message:Hello I am Mariah Porter and I am from Sioux city IA. I am a Animal science major/prevet . I am in the Army Res. 949th medical unit(VET) I love ISU and it's people. I love messing with plants and animals so ISU seemed like the right choice !
=========yorg=========
===from:Elizabeth Moudry
===email:emoudry@iastate.edu
===date:Thu Aug 30 22:52:03 2001
===subject:Introduction
===message:I am Elizabeth Moudry.  I am originally from Afton Minnesota, which is about thirty minutes from the Twin Cities.  I am an Agriculture Undecided, which basically means I have no idea what I want to do yet.  I am a freshman and I so far love ISU.  I have nothing else that is worth mentioning so I guess that's it.


=========yorg=========
===from:Logan Anderson
===date:Thu Aug 30 23:04:22 2001
===subject:Biology 201
===message:My name is Logan Anderson.  I am a freshman from Eldora, IA.  My major is undecided in the college of Liberal Arts and Sciences.  I'm pretty much taking this class because I have no idea what I want to be.  I like the subject biology, but I'm not very good at it.
=========yorg=========
===from:Chelcee Jolee Hindman
===date:Thu Aug 30 23:04:44 2001
===subject:Bio 201
===message:Hi, I'm Chelcee.  I am a farm girl, and I love my animals.  I grew up on a farm north and just a little bit east of Ames.  I love showing cattle and pigs.  I also have horses, a mule, a donkey, 5 dogs, cats, a rabbit, and 3 minature milking goats---to keep the ringworm away from my show cattle.  I'm majoring in Animal Science.  Just a little fact---I'm a black belt in Taekwondo--but since I recieved it, I'm not active.  
=========yorg=========
===from:Nichole Fondell
===email:nfondell@iastate.edu
===date:Thu Aug 30 23:47:02 2001
===subject:introduction
===message:Hello! I am Freshman from Dubuque, Ia.  I'm pretty excited about being here at ISU.  I am a Biology majors, with intentions of going on into the feild of Veterinarian Medicine.
=========yorg=========
===from:Sarah Muhs
===date:Fri Aug 31  0:08:26 2001
===subject:All About Me
===message:Hi, everyone!  I am 24 years old and I'm majoring in Sociology. I am originally from Southern Illinois but just moved to Iowa in August because I got married and my husband works for Pella Corp.  I attended college briefly after graduating from high school in 1995 and have now decided to go back to finish my degree.  I am enjoying Iowa and Iowa State and I'm hoping that this time around I'll be leaving college with a degree! ;)
=========yorg=========
===from:Darius Robinson
===date:Fri Aug 31  0:27:09 2001
===subject:Introduction
===message:My name is Darius Robinson. I am a sophmore and a history major.  I like to bike and run.  My future plans are to become a Marine Corps officer.
=========yorg=========
===from:Carrie
===date:Fri Aug 31  2:23:39 2001
===subject:about me
===message:hi, i'm carrie from naperville,il (it's a suburb of chicago) I'm a bio environmental science major, i want to work for conservation and environmental protection. i live in friley on a wise floor and i'm in the honors program. that's it i guess. 
=========yorg=========
===from:Matt Carlson
===date:Fri Aug 31  2:46:28 2001
===subject:whats up
===message:hi all. im matt carlson and my major is horticulture. i enjoy hanging out with friends, partying, listening to my cds, and always looking to have fun. if most of you are like me and think biology is tough, then we have something in common. on one final note, if u havent seen american pie 2, i recommend u go see it.
=========yorg=========
===from:Adam Hoffman
===email:ahoff43@iastate.edu
===date:Fri Aug 31  8:24:04 2001
===subject:my intro
===message:hey everyone. i'm a hort major in the turf department.  i'm from sibley iowa, a dinky town in the northwest corner of iowa.  GO CYCLONES!!!
=========yorg=========
===from:Mandi Alley
===email:tigeress79ma@excite.com
===date:Fri Aug 31  9:37:38 2001
===subject:About Me!
===message:I am from Glenwood, IA. I have recently moved to Des 
Moines and live with my cousin.
   I am majoring in Forestry-Natural Resource 
Conservation. I am minoring in Animal Ecology.
     I love animals, wildlife, being outdoors and spending 
time with my friends.

=========yorg=========
===from:Dennis Portz
===date:Fri Aug 31  9:43:28 2001
===subject:Intro
===message:I just recently transfered from Clinton Community College in Clinton, Iowa. Clinton is 30 miles north of the Quad Cities. I am now a Horticulture student here and would like to get into plant propagation and greenhouse managment.
=========yorg=========
===from:Ling-Yi Su
===date:Fri Aug 31 10:22:52 2001
===subject:Myself
===message:My name is Ling-Yi Su. I am from Taiwan where took me 20 hours by airplane to be here. My major is Nutrition. I like to see the movies,  listen to rock music, and chat with friends.   
=========yorg=========
===from:Ling-Yi Su
===date:Fri Aug 31 10:23:06 2001
===subject:Myself
===message:My name is Ling-Yi Su. I am from Taiwan where took me 20 hours by airplane to be here. My major is Nutrition. I like to see the movies,  listen to rock music, and chat with friends.   
=========yorg=========
===from:Beau Wisecup
===date:Fri Aug 31 10:49:11 2001
===subject:Hello
===message:What's up?  My name is Beau and I'm majoring in horticulture.  I like to do all sorts of stuff but my favorite things are rock climbing and disc golf.
=========yorg=========
===from:Jordan Van Ness
===email:docj74@iastate.edu
===date:Fri Aug 31 11:31:18 2001
===subject:Bio-1
===message:Hi my name is Jordan and I'm a freshman majoring in pre-med with emphasis in emergency medicine. I graduated from Pleasantville high school which is around 45 min. south of Ames. While in Pleasantville I was active in our fire department and our EMS, it has been an experience that I will never forget.  I would recommend that if you ever have the chance to try out or join one of these services you do because it is an awesome time.  I enjoyed it so much that I am planning to take my EMT-B starting in January.  Here at ISU I plan to get involved in as many different activities as possible.  I also am joining the Pi Kappa Alpha Faternity. I don't really know what else to say, but if you have any questions for me just e-mail me and I'll respond back asap
=========yorg=========
===from:Melinda Brogly
===email:mbrogly@iastate.edu
===date:Fri Aug 31 11:52:53 2001
===subject:New Student Introductions
===message:Hello. My name is Melinda but I go by Mindy.  I am from 
Muscatine, Iowa which is on the Mississippi and about 
one hour south of Davenport.  I have one sister named 
Melody who is a freshman at our local high school.  I 
also have two dogs at home and one fish that lives with 
me here at ISU.  I love studying biology and learning 
about life.  I have a passion for animals which is why I 
am majoring in animal science with the hope of being 
accepted into vet school.  I plan on specializing on large 
animals (mainly horses and cattle but I hate hogs with 
a passion).  I have been a member of the FFA for three 
years and I have participated in many FFA events.  
=========yorg=========
===from:Jessica Edge
===date:Fri Aug 31 11:53:49 2001
===subject:about me
===message:Hi everyone! My name is Jessica Edge, and I'm from Humboldt,
Iowa. (in the North Central area) I am going to major in
Animal Science. I grew up on a family farm, with cattle,
horses and row crops. I showed cattle and horses through 4-H
and FFA, as well as many other great activities. I plan to
have an awesome year here at Iowa State, and hope everyone
else does, too!
=========yorg=========
===from:Jessica Parkhurst
===email:jparkhur@iastate.edu
===date:Fri Aug 31 12:00:47 2001
===subject:hello
===message:My name is Jessica Parkhurst and I am a junior in Animal Ecology; Pre-Vet and Wildlife Care.  I am from Waterloo and went to Columbus HS.  This is my first year at Iowa State; I transferred here from the University of Illinois at Urbana-Champaign.  I spent two years there as a vocal perfomance major but then decided, like Professor Schaus, that I might want to look into something that would pay the bills!
=========yorg=========
===from:Jenn Anderson
===email:jenn49@iastate.edu
===date:Fri Aug 31 12:33:44 2001
===subject:Remembering me and myself
===message:Hello. I'm Jenn. I'm from Aurora, IL, about 45 minutes from Chicago.<BR><BR>

My majors are forestry and biochemistry, and hopefully I'll have a minor in biomedical illustration.<BR><BR>

My favorite things to do are draw, read comics, party, and watch <a href="http://www.geocities.com/jenn_49/">John Cusack</a> and Christopher Walken movies. My favorite movie is <b>"Suicide Kings"</b> and my favorite comic at the moment is <b>Hellboy</b>, although that is subject to change.<BR><BR>

I'm also really into music. My top five favorite bands of all time, in no particular order, are:<BR><BR>

The Clash<BR>
The Ramones<BR>
The Sex Pistols<BR>
Black Sabbath<BR>
Van Halen<BR><BR>

Back home my best friend has a TV show that will start airing within the next month, and I'd appreciate it if you would go check out <a href="http://www.geocities.com/thebonejangler/">his website</a>, but please don't tell him that I sent you! Most of the action at the site is on the message board, so if you go, definately check that out.<br><BR>

Thanks!<BR>
Jenn
=========yorg=========
===from:Jake Maher
===date:Fri Aug 31 12:46:57 2001
===subject:about me
===message:My name is jake maher and I am a freshman here and my major is animal science.  I play hockey for ISU and am also working part time.  I'm just taking this class becuase it's required.....so i hope i do well.  I'm also from omaha, NE.
=========yorg=========
===from:Jacki Timmons
===email:jjtimmon@iastate.edu
===date:Fri Aug 31 12:49:04 2001
===subject:Bio intro
===message:Hey whats up?! My name is Jacki Timmons. I am from Omaha, NE(go cornhuskers!!!) and my major is Animal Ecology. I hope someday to run the childrens programs at a Zoo or a national park. Anyways, thats about all my life consists of right now. see ya in class.
=========yorg=========
===from:Kyla Straub
===date:Fri Aug 31 13:07:43 2001
===subject:About me
===message:My name is Kyla Straub. I am a sophmore from Peterson,IA.  I am taking this class because I am going into Pre Med and it is a requirement.
=========yorg=========
===from:nathan fedde
===date:Fri Aug 31 13:20:01 2001
===subject:intro
===message:Hi, I'm Nate.  I'm from Amana, IA. I plan to go on to med school or get employed right after graduation. I'm majoring in Biochemistry because I love science and I wanna make mad cash.
=========yorg=========
===from:Alissa Fordice
===date:Fri Aug 31 14:53:40 2001
===subject:Bio intro
===message:Hi I'm Alissa. I'm from MinnesOta :)  I'm a sophomore and I'm majoring in French.  I am Hort minor and I'm also doing pre-professional health pre-recs.  I too wanted to do a voice major but hey Mr. Schaus is right it doesn't pay the bills.
Anyway, my fav things to do are voice, surfing and interior design/art type stuff.  Hope everyone is having a great semester so far!
See ya 
=========yorg=========
===from:Michael Kass
===email:kassma@iastate.edu
===date:Fri Aug 31 15:07:27 2001
===subject:bio intro
===message:Hi, my name is Michael Kass.  I'm from Washington, IA, which is about a half an hour drive south of Iowa City. I have two brother, a sister, and a dog
.
=========yorg=========
===from:Ryan Elgin
===email:rpe@iastate.edu
===date:Fri Aug 31 16:50:04 2001
===subject:about me
===message:Hello,

   I'm Ryan Elgin, I am a Sophomore in Ag Business with a minor in Agronomy.  This is the first Biology class that I have taken a ISU.  I am originally from Adair, IA, which is about 45 miles west of Des Moines on interstate 80.  If you have ever been by there I'm sure you noticed the bright yellow smiley face water tower and wind turbine.  That is pretty much all Adair has to offer.  I grew up on a small farm that raises corn and soybeans and a few finishing hogs.
Hope you have a great year.  SEE YA!
=========yorg=========
===from:Alicia 
===date:Fri Aug 31 18:05:54 2001
===subject:About Me!
===message:So, you want to know about me?  Well, you came to the right place.  I am a 17 year old Freshman in the Animal Science/Pre-Vet Major.  I grew up on a farm in Northwest Iowa.  I attended South O'Brien High School.  I raise and show angus cattle.  I also enjoy riding horses.  I hope to complete my college education and becaome a vet.  If there's anything else you would like to know about me just give me a call, my number is 572-1930.
Thanks for reading,
mandi
=========yorg=========
===from:Maryn Ptaschinski
===date:Fri Aug 31 18:35:14 2001
===subject:hi there!
===message:Hi! My name is Maryn (like erin with an M) and I'm a 19 year old freshman majoring in agricultural education and pre-vet. In case you're wondering why i'm nineteen, it's because i took the year off of college last year to serve as the Wisconsin FFA Secretary. Yup! that's right! i'm from sun prairie WI, the land of cheese, brats, and beer. I like to ride horses and i show registered hereford cattle, but i don't live on a farm. i was pretty active in a variety of things in high school and i'm a national merit scholar. If you want to talk to me you can stop in at 4301 Larch or call 572-0205. 
=========yorg=========
===from:Stephanie Burdess
===date:Fri Aug 31 21:32:48 2001
===subject:myself
===message:My name is Stephanie Burdess.  I am from Boone, IA.  This is my second year at Iowa State.  I am an animal Science Pre-vet major.
=========yorg=========
===from:Pat
===date:Sat Sep  1 18:36:48 2001
===subject:info on me
===message:Whats up everyone, my name is Pat Hennessy. I am a sophomore and my major is biology. My home town is ankeny, Ia. 
=========yorg=========
===from:Sandra Colchado
===email:sandrac@iastate.edu
===date:Mon Sep  3 20:21:21 2001
===subject:me
===message:Hi everyone. My name is Sandra. I'm a junior in psychology. I'm from the north side of Chicago. My favorite musical is Cabaret. I love music by Third eye blind. I love to dance Flamenco and the summer of '99, I lived in Spain.
=========yorg=========
===from:Tricia Lindgren
===date:Tue Sep  4 17:08:37 2001
===subject:Hi
===message:Hi. My name is Tricia and I'm from Churdan Iowa.  Right now I'm not sure what my major is so I'm in Ag. undecided.
=========yorg=========
===from:Carrie Sanneman
===date:Tue Sep  4 17:38:46 2001
===subject:a brief introduction
===message:My name is Carrie, I am a biology major and i want to 
go into environmental protection and conservation. I like 
classic and alternative rock, I like in friley and i have had 
an awesome first two weeks.
=========yorg=========
===from:Kayla Tott
===date:Wed Sep  5  9:53:23 2001
===subject:Hello
===message:Hi, I am Kayla Tott.  You met me in your office the other day.  I was asking you about switching my lab.  Thanks for all your help.  It wasn't a nightmare afterall.  Linda was very helpful.  I am looking forward to your next class.
=========yorg=========
===from:Todd Slycord
===date:Wed Sep  5 19:10:31 2001
===subject:Allow me to introduce myself....myself
===message:Sup yall, i'm a jr. majoring in excercise sports engineering and hoping to become an orthodontist one distant day in the future.  I'm originally from West DesMoines, IA, and i love sports and the outdoors.
=========yorg=========
===from:matt campbell
===email:december@iastate.edu
===date:Tue Sep 11 17:58:49 2001
===subject:biology 201
===message:i changed majors after the first week of classes.  i'm gonna play catch up for a week before i'm all caught up.  i like science better than art cos i'm gonna learn new stuff instead of listening to what i already know.
=========yorg=========
===from:Mike Tibbles
===date:Wed Sep 12  9:15:30 2001
===subject:introduction
===message:I am enrolled in the LA program and need this class for a hort minor so i am not perticularlly excited about this class
=========yorg=========
===from:Ariel Chandra Jaya
===date:Tue Sep 18  7:42:44 2001
===subject:Nice to meet you all
===message:Hi! My name is Ariel Chandra. I'm from Indonesia. My major is Computer Science and I took this class because I have an interest in Biology. Thanks and hope to work with you  all soon

ARiel
=========yorg=========
