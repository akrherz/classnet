===from:Matt Farrell
===email:mqscft@iastate.edu
===date:Thu Oct 11 22:21:41 2001
===subject:Support for Creationists
===message:You made a very good point when you stated God may have intended for the Big Bang to happen.  Probability plays a major role in science and it is not very probable that the Big Bang "just happened".  Nor is it probable that life just occurred.  I believe this, and the number of questions left unanswered by evolutionists, is the biggets support for Creationism.
=========yorg=========
===from:Kellen Ludvigson
===date:Sun Oct 14 11:12:51 2001
===subject:A good point
===message:I really agreed with the point nothing could be created out of nothing.  That made me start to think, how was the big bang created itself.  If something caused a great explosion...what made the material that exploded.  Somewhere something had to be made out of nothing!
=========yorg=========
