===from:Scott Schaus
===date:Thu Oct 25 14:57:59 2001
===subject:Molecular Clocks
===message:See page 481 of your text for a few paragraphs concerning molecular clocks.

The main idea is that if two organisms have a common ancestry, comparisons of homologous DNA and proteins from those orgs can yield information about the time that has elapsed since the orgs lineages branched.
<BR><BR>
A key assumption is that the mutation rates for genes are fairly constant. Is this reasonable?...
<BR><BR>
Scott
=========yorg=========
