===from:Scott Schaus
===date:Fri Oct  5  0:00:05 2001
===subject:Fixed allele mutations
===message:Sure...if an allele is fixed in a gene pool, it is still subject to chance mutations. Mutations, by definition, are random alterations in the DNA, so fixed alleles are not exempt from mutations. But, consider the rate of mutation, and that most are revesible, so...
<br>
Scott
=========yorg=========
