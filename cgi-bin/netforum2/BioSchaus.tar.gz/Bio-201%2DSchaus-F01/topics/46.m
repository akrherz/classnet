===from:Kelly Virgil
===email:kvirgil@iastate.edu
===date:Fri Oct 12 16:30:23 2001
===subject:Big Bang and Evolution
===message:I agree that the big bang and evolution are possible to an extent.  I really feel that there has to be a connection between creation and evolution though.  If god did create things then is it unreasonable to think that god made evolution possible too.  I also have trouble fully believing in evolution because of all the gaps in the factual information.  I believe that certain species can adapt to new environments and possibly over time evolve but I don't know for sure if I believe certain species could evolve into totally new species.
=========yorg=========
===from:Kellen Ludvigson
===date:Sun Oct 14 10:59:10 2001
===subject:homologous structures?
===message:Homologuous structures do bring up an interesting point.  There is no doubt that many structures among different animals are very similar even when used for different things.  However, an interesting thing to consider is...if a particular design is efficient and works well...why change it a great deal..just modify it slightly!
=========yorg=========
===from:Ashlie Mcwee
===date:Sun Oct 14 15:27:31 2001
===subject:response
===message:I agree that evoultion is one of the reasons for us being here today, but I'm curious to know what is the overwhelming amount of scientific information that you have that proves that is the case? Mentioning of  homologus structures is very interesting. That would have been nice if you had elaborated more on that topic.
=========yorg=========
