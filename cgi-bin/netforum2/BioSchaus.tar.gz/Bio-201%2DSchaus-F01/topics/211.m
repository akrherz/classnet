===from:JJ Steuk
===email:jjsteuk@iastate.edu
===date:Wed Nov 28 21:58:38 2001
===subject:Skin color and evolution
===message:Skin color could possibly have come from the evolution of people in different areas of the world. This can be seen if you look at the regions of the world and the ethnicity of the in habititans.One theory of why the people in different ares of the world look different is that the climate affects for example skin color, and that is why it could be possible that the people in all these regions have desended from one area and then repopulated the areas and adapted.
=========yorg=========
