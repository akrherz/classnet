===from:Scott Schaus
===date:Fri Oct  5 10:02:08 2001
===subject:Alleles and diseases
===message:Jennifer:
<br>
The key concept to clear things up is that alleles (genes) carry the <b>code</b> for proteins and ultimately other molecules. The genes (alleles) themselves do not directly "cause" a disease or problem; sometimes the product produced from the code in the gene may be harmful, sometimes beneficial. It is important to NOT associate mutant or recessive with a problem or disease necessarily, but to instead think of the terms as indicating inheritance patterns. In the case of carriers (heterozygotes), sometimes it is beneficial (as in resistance to malaria for sickle-cell trait) and in others it is deleterious (partial disease or problems in many cases).
<br>
HTH,
<br>
Scott
=========yorg=========
