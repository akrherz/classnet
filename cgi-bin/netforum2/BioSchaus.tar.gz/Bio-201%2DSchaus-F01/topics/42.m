===from:Sharon Brown
===email:scbrown@iastate.edu
===date:Sun Oct 14 14:49:51 2001
===subject:reply to group 19
===message:The is evidence to support Darwin's theories and microevolution.  Macroevoultion is the main question in your debate.  Did we actually evolve from another organism, or more specificly Apes?  There is evidence supporting macroevolution, yet evoultion is still open to question.  There is not enough evidence to support evoultion as a fact.  Two main arguments against evoultion are that there are no transition fossils and that thermodynamic laws state that chain reactions become simpiler as time continues.  I don't think we can totally throw out the theory of evoultion and point to God, nor can we do the reverse, with the data and information we have arguing either side.  As to believing the Bible or the Scientific text book...That is a personal choice, which is hard to debate upon.
=========yorg=========
