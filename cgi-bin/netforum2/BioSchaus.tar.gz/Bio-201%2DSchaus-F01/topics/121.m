===from:Kelli Kopf
===date:Thu Nov  8 16:14:52 2001
===subject:Response to Fluke Question
===message:I found an answer to your question.  There are three main species of the blood fluke.  The Schistosoma haematobium is found only in Africa and the Middle East.  The Shistosoma mansoni is found in Africa, the Middle East, and South America.  The Schistosoma japonicum, which is found only in the Far East.  So cases involving a blood fluke in Iowa are very rare.  This could only happen if someone traveled over seas to one of these countries and carried a blood fluke back.  Someone could also pick one up from a labratory.  I am sure that the SHC has seen no cases involving a blood fluke.   (I could not figure out how to italicize the genus and species.  I apologize for that.)
=========yorg=========
