===from:Adam Hoffman
===email:ahoff43@iastate.edu
===date:Fri Nov  9 12:00:55 2001
===subject:Assignment #8
===message:The website on invertebrate research that i have found is http://www.unp.ac.za/UNPDepartments/zoo/depicrc.html
The site explains the different conservation practices used in South Africa to conserve these organisms.  The site also gives a detailed list of the many studies and researches that they have conducted with invertebrates.  It also lists the lastest and current research studies that they are conducting for the conservation of these organsisms. The main organisms that they study are: dragonflies, butterflies, grasshoppers and carabid beetles. 

=========yorg=========
