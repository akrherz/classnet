===from:Erin Brown
===date:Tue Sep 25 14:48:17 2001
===subject:Genetics
===message:ok,  I had a thought,  I know that hair color is affected by more than one gene.  Some genes (like that for Parkinson's disease)  are not expressed until a certain age.  Could one of the other genes affecting hair color also have full expression delayed until the child got older? In that case, the light color wouldn't really be blonde, it would be more a lack of pigmentation, like albino.
=========yorg=========
