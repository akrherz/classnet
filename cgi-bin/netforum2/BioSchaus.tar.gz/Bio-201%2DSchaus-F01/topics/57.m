===from:Sharon Brown
===date:Sat Oct 20 10:32:11 2001
===subject:Question for group 41
===message:Since the Bible was in fact written thousands of years ago and translated numberous times, is it possible the the Bible has been streched from it's origional context, much like all other folk tales passed down by the word of mouth?  
=========yorg=========
