===from:Ryan Schnoes
===date:Wed Oct 24 12:43:11 2001
===subject:Biology
===message:I believe that the earth and all that is or was present on Earth was created by God.  The Big Bang is a good theory, but how did  the Earth, or anything else for that matter, become about without some higher form of being. I think that God created Earth in seven days, with different creations occuring every different day.  To me as a creationist, it is the easiest way of explaining how Earth and it's living beings came about. Once the Earth was created by God, then the process of evolution could take place. So, I support both creation and evolution. However, my idea of creation is not due to the Big Bang, it is due to God himself creating it. 
=========yorg=========
