===from:Scott Schaus
===date:Tue Sep 25 23:00:07 2001
===subject:No male calico cats!!
===message:Kelly:
<br>
There are NO male calico cats, with the possible exception of a mutation. See this web page for more info:

http://www.rettsyndrome.org/main/genetics_of_rett_syndrome.htm

and this web page:

http://www.biology87.org/apbio/notes/4_VI.htm
<br>
<br>
Scott
=========yorg=========
