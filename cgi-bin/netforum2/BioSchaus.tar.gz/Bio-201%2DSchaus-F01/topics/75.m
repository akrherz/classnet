===from:Jon
===date:Mon Oct 15 16:40:46 2001
===subject:Activity
===message:<pre>PEOPLE

Father of Taxonomy
Linneaus

Theory of Gradualism
Hutton

Developed binomial nomenclature
Linneaus

Founded paleontology
Cuvier

Founded the catastrophism theory
Cuvier

In 1809 this person proposed and published a mechanism for evolution
(hint: Giraffe necks)
Jean Baptiste Lamark
Bonus: This theory was known as what? (The use and disuse theory)

First theorized that overpopulation leads to a lack of food supply
Malthus

A geologist that discovered uniformitarianism
(Lyell)

Theorized that life is scala naturae
Aristotle

Teacher to Aristotle
Plato

Said that nothing is real and that we are just reflections of what is real
Plato

Guy who worked with fruit flies
Thomas Hunt Morgan

Two people who developed the Punctuated equilibrium model of evolution
Niles Eldridge and Stephen Jay Gould 
GENETICS


Used to find the probability that independent events will occur at the same time
Rule of multiplication

The Phenomena where two alleles can have 3 distinct phenotypes
Codominance

 The Phenomena where two alleles can have 1 dominant, 1 recessive, and 1 blended phenotype
Incomplete dominance

The Phenomena where 3 or more alleles determine a phenotype
Multiple alleles (or polygenic inheritance)

The Phenomena where one gene modifies the expression of another
Epistasis

The Phenomena where one gene affects many functions
Pleiotropy

 
DISEASES

Lethal recessive disease which has a q2 of 1/2500 Caucasians
Cystic Fibrosis

Tay Sachs affects 1/3600 of this group
Ashkenazi Jews

Recessive trait that effects 1/400 African Americans
Sickle cell
Bonus: What is the p value? (q2=1/400=.0025  q=sqrt(.0025)=.05   p=1-q=.95)
0.95 (95%)

A lethal disease that affects mostly men that are 30-40 years old
Huntington�s disease
Bonus: is it dominant or recessive? (Dominant)

Disease where the homozygous dominant fetus is spontaneously aborted
Achondroplasia (dwarfism)

Heterozygotes show this disease which accounts for 1/10000 of the population
Dwarfism

Disease that is caused by a trisomic individual for chromosome 21
Downs syndrome

 
MISC

Segregation happens in this meiotic step
Anaphase I

Individual assortment happens in this meiotic step
Metaphase I

Drosophilia Melanogasters diploid number
8

A males has no second X chromosome and is therefore ____ for each sex linked trait
Hemizygous

Hemophilia, Muscular dystrophy, & hemophilia are all _____ _____
Sex linked

The inactivated X chromosome in women
Barr body

The key mechanism in alterations of the chromosomal #
Non-disjunction

And orgasm with an extra chromosome
Trisomic

ABCD � ACD
Deletion

ABCD � ABCBCD
Duplication

ABCD � ACDB
Translocations

ABCD � ADCB
Inversions

Tetraploidy is common in some species of this kingdom
Plantae

Mitochondria are inherited through this mechanism
Extranuclear maternal inheritance

 
MICRO EVOLUTION

Smallest unit of microevolution change
Population

Changes in a gene pool of a small population due to chance
Genetic Drift

Phenomenon where a few individuals colonize a new habitat
Founder Effect

A natural disaster may lead to this type of change in the gene pool
Bottlenecking

Transfer of genetic material between two populations
Gene Flow

Inbreeding is an example of this cause of microevolution
Nonrandom mating

The only agent of microevolution that is adaptive and disturbs genetic equilibrium
Natural Selection

The contribution of an individual�s genes to the gene pool
Evolutionary fitness

The contribution of an individual�s genes to the gene pool relative to someone else
Relative fitness

This selection effect favors variants of one extreme or another
Directional selection

This selection effect favors both opposite extremes over the original variant
Diversifying

This selection effect favors intermediates
Stabilizing selection


 
SPECIATION (MACROEVOLUTION)

Mode of speciation where the parent species disappears
Anagenesis

The most common mode of speciation
Cladogenesis

Founded the Biological Species concept
Emst Mayr (1942)

Population or groups of populations whose members have the potential to interbreed with one another in nature to produce viable, fertile offspring
Biological Species Concept

Barrier to speciation that involves two similar species living in different areas
Habitat isolation

Barrier to speciation that involves different breeding seasons
Temporal isolation

Barrier to speciation that involves pH differences that kill sperm
Gametic Isolation

Barrier to speciation that involves the child being sterile
Hybrid invalidity

Barrier to speciation that involves anatomic incompatibility
Mechanical Isolation

Mode of speciation where a geographic barrier separates two populations
Allopatric speciation

Mode of speciation where species form within the geographical constraints of the parent population
Sympatric speciation

The amount of generations needed for a rapid evolutionary change
Roughly 1000

The phenomena where the adult species retains features from a juvenile form
Paedomorphism

The difference in the rate of growth of different body parts
Allometric Growth

Evolutionary alteration in the placement of different body parts
Homeosis
 
Fossils and Eras

Inorganic compounds left after the death of an organism
Fossils

The period of time that radiometric dating is accurate over (i.e. when does radiometric dating fail)
50,000 years

Marks the barriers of eras
Mass Extinctions

Marks the start of an era
Adaptive radiation

The most recent era
Holocene

The zone where a heavy tectonic plate rolls under a lighter tectonic plate
Subdivision zone

Goes up as the extinction rate lowers
Family number

Two of the most important extinctions
Permian and Cretaceous

Theorizes that a large object hit the earth, causing extinction
Impact Theory

 
Phylogeny

Study of the diversity of life
Systematics

The naming convention that uses both a genus and species name to define an organism
Binomial naming

The idea taxon is _____ meaning that it has 1 common ancestor
Monophyletic

A likeness due to shared ancestry
Homology

Similarities due to convergent evolution
Analogy

Arrival at a similar structure due to function not an ancestor
Convergent evolution

Compares anatomic characteristics without sorting homology from analogy
Phenetics

The phylogenic system that only considers homologic traits
Cladistics

A shared derived characteristic
Synapomorphies

 
Prokaryotes

The hotdog shaped bacteria
Bacillius

Reproduction method of prokaryotes
Binary Fission

Bacterial genetic recombination where a gene is ingested from the environment
Transformation

Bacterial genetic recombination where a sex pillius attaches between bacteria
Conjugation

Bacterial genetic recombination where a virus transfers genetic material
Transduction

Uses light as energy and CO2 for carbon
Photoautotrophs

Uses inorganic chemicals as energy and CO2 for carbon
Chemoautotrophs

Uses light as energy and organic compounds for carbon
Photoheterotrophs

Uses inorganic chemicals as energy and organic compounds for carbon
Chemoheterotrophs

Ingests dead or decaying matter for a carbon source
Saprobes

Attains carbon from a living source
Parasite

The only prokaryotes capable of releasing O2 from H2O
Cyanobacteria

Organism that cannot tolerate oxygen
Obligate anaerobes

Organism that must breathe oxygen
Obligate aerobes

This type of bacteria is a strict anaerobe, which combines hydrogen and carbon dioxide to form methane
Methanogens

This type of bacteria lives in strong salt concentrations
Extreme halophiles

This type of bacteria lives in high temperatures
Extreme thermophiles

The smallest type of bacteria which also causes walking pneumonia
Mycoplasma (Gram Positive)

Bacteria that causes syphilis
Treponema pallidum

Bacteria that causes an STD and possibly blindness
Chlamidias

Anthrax is a Gram _____ bacteria
Positive

The three methods of contracting anthrax
Cutaneously, ingestion, inhalation
</pre>
=========yorg=========
===from:Jon
===date:Mon Oct 15 17:02:10 2001
===subject:Student-made quiz
===message:<pre>Student Quiz

1) For the Hardy-Weinberg equilibrium to work you must not have which of these conditions:
a)	Isolation from other populations
b)	Random mating
c)	No mutation
d)	Non-random mating

2) Which of the following is not a type of selection?
a)	Stabilizing
b)	Destabilizing
c)	Directional
d)	Diversifying

3) A gene pool consists of:
a)	The total combined genes in a population at any time
b)	 Extensive genetic variation within populations
c)	Integrated discoveries and ideas from many fields focusing on synthesis
d)	A group whose individuals have the potential to interbreed

4) Which of these is not on of the causes of microevolution?
a)	Gene flow
b)	Genetic drift
c)	Random mating
d)	Natural selection

5) Which of the following represents a probable order of evolution of the pre-life components of earth
a)	An oxidizing atmosphere followed by a reducing atmosphere
b)	Amino acids and sugars after corresponding polymers
c)	DNA before RNA
d)	Eukaryotes before photosynthesis

6)	Which of the following steps has not yet been accomplished by scientists studying the origins of life?
a)	Abiotic synthesis of polypeptides
b)	Formation of molecular aggregates with selectively permeable membranes
c)	Formation of protobionts that use DNA to direct the polymerization of amino acids
d)	All of the above
e)	None of the above

7)	Aristotle�s ladder theory states
a)	Organisms have a set place on the ladder
b)	Organisms can move freely up or down the ladder
c)	Organisms can only move up the ladder
d)	Organisms can only move down the ladder
 
</pre>
=========yorg=========
===from:Jon
===date:Mon Oct 15 17:02:45 2001
===subject:Student-made quiz answers
===message:<pre>Answers for student quiz
1)	D
2)	B
3)	A
4)	C
5)	B
6)	D
7)	A
</pre>
=========yorg=========
===from:Jon
===date:Mon Oct 15 17:04:12 2001
===subject:Read me first
===message:<pre>Here are the worksheets that I used in SI on October 15, 2001. 
The important thing here is that you do not use this as your sole study guide. It should be used only to see what you do and do not know so you can study certain sections. Once again, I do not know what will be on the test so the information herein is just a study reference. 
The best way to study would be to review your class notes, read the book, and complete the questions at the end of the chapters. Any questions over specific material should be sent to Professor Schaus. 
-Jon 
</pre>
=========yorg=========
