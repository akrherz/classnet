===from:erin brown
===date:Tue Oct  2 18:38:35 2001
===subject:Breeding of different species
===message:Ok,  could it be that the reason that mules are sterile is because of the uneven combination of chromosomes from the parents?   I don't remember where I read it,  but I do think it matters which parent is which species. For some reason I think that if the parents were switched the resulting offspring would have a different species designation.  
=========yorg=========
===from:Scott Schaus
===date:Thu Oct  4 23:51:17 2001
===subject:Mules & Hinneys
===message:Hi:

If the father is a donkey (jack) and the mother is an horse (mare), the offspring is a mule. If the mother is a donkey (jenny or jennet) and the father is a horse (stallion), the offspring is a hinny.
<BR>
Sharon is correct on the chromo numbers (2n=64 and 2n=62) resulting in 2n=63 for the mule. During synapsis, there are no homologs to pair up, therefore meiosis goes awry and the mule is sterile.
<br>
Scott
=========yorg=========
===from:Kelli Kopf
===date:Sun Oct  7 23:56:41 2001
===subject:Cabbit?
===message:I was watching Animal Planet the other day and the show Amazing Animal Videos was on.  They were showing footage of a little kitten running around.  I looked closer and I noticed it wasn't running, but rather hopping much like a rabbit does. Its hind legs were shorter or something and were more anatomically like a rabbit's hind legs.  The people on the show called it a Cabbit (a cross between a cat and a rabbit).  One scientist came on the show and said that it was impossible for a cat and a rabbit to mate.  He said that the kittens were hopping instead of running like normal kittens because the joints in their back legs were deformed.  Animal Planet said that there have only been 3 or 4 cabbits reported.  Is it possible for a cat and a rabbit to mate?  Are Cabbits real?
=========yorg=========
