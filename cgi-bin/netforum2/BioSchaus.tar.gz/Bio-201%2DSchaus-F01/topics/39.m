===from:Matt Farrell
===email:mqscft@iastate.edu
===date:Thu Oct 11 22:31:38 2001
===subject:The topic of God
===message:Your discussion alludes to many points other groups did not mention.  I agree with the group member who thinks it improbable for God to poof and things occurred.  I also believe the Bible plays too big of a part in Creationists thinking.  The Bible was interpreted by man, who often makes mistakes.  All "religions" are were somehow created, or set up by man.  Although human beings are suppose to be unique because they are created in God's Image, I believe GOd and the concept of God is far beyond our thinking.  I don't think God even considers the questions we ask about him.  God may be a ruler who only creates then lets go of.  Because no evidence of God has ever been directly observable in our world, I personally believe he exists outside of our world, making it impossible for us to even ponder him, as I am attempting to do.
=========yorg=========
