===from:Erin Brown
===date:Thu Sep 27  0:33:37 2001
===subject:inactive x chromosome
===message:Hey,  thank you.  That is exactly what I was trying to ask earlier,  but you said it better.  At least I know I'm not the only one.  So can anyone share their ideas on how this works, please?
=========yorg=========
