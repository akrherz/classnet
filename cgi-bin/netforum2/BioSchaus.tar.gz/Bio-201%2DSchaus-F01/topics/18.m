===from:Jon
===date:Thu Sep 13 23:54:13 2001
===subject:Read me first
===message:Here are the worksheets that I used in SI on September 13, 2001. 
<br>
The important thing here is that you do not use this as your sole study guide. It should be used only to see what you do and do not know so you can study certain sections.  Once again, I do not know what will be on the test so the information herein is just a study reference. 
<br>
The best way to study would be to review your class notes, read the book, and complete the questions at the end of the chapters. Any questions over specific material should be sent to Professor Schaus.
<br>
-Jon
=========yorg=========
===from:Jon
===date:Thu Sep 13 23:56:11 2001
===subject:Here are the review materials used in SI (9-13-01)
===message:<pre>SMART COOKIES (PEOPLE)

$50
Played with peas and discovered the basis for genetics (Who is Gregor Mendel)

$100
The guy who discovered Cells in 1665 (Who is Robert Hooke?)

$200
Leeuwenhoek (Who discovered the light microscope?)

$300
Schleiden and Schwann (Who made the cell theory?)
BONUS:
$100 per correct answer
What is the main component of the cell theory? (The cell is the basic unit of structure and function for an organism)

$400
Sydney Fox (Who found protenoids formed on clay?)

$500
Tom Cech (Who discovered Ribozymes)

$600
Hypothesized that primitive earth had a volcanic vapor atmosphere (Who is Oparin-Haldane?)
BONUS:
Who tested this hypothesis? (Miller-Urey)

$700
Wrote a very important document in 1859 (Who is Darwin)
What is the name of the document? (On the Origin of Species)
 

MISC QUESTIONS

$100
Haploid reproductive cell (Gamete)

$200
Display of individual�s somatic cell metaphase chromosomes. (Karyotype)

$300
Pair of chromosomes that have the same size centromere, position, and loci. (homologous chromosomes)

$400
The most important checkpoint in many cells (What is G1)

$500
The type of cell division by which prokaryotes reproduce; each dividing daughter cell receives a copy of the single parental chromosome (what is binary fision)

$600
MPF (What is the Maturation Promoting Factor, he called it Mitosis Promoting Factor for memory)
BONUS
What gate does this guard? (Mitosis)
BIG BONUS
What enzyme creates this? (cyclin-dependant kinase)

$700
The multicellular diploid form in organisms undergoing alternation of generations that results from a union of gametes and meiotically produces haploid spores (Sporophytes)

$800
A glycoprotein in the extracellular matrix of animal cells, rich in carbohydrate (What is a Proteoglycan?)

$900
A circular flow of cytoplasm involving myosin and actin filaments that speeds the distribution of materials within the cell (What is Cytoplasmic Streaming)

$1000
Enzymes that transfer a phosphate from ATP to the substrate (what is a Kinase)
 

TWO FROM ONE

$2
Phase that has sister chromatids aligned on the metaphase plate (metaphase)

$100
The phase that contains G1, S, and G2 (What is interphase?)

$200
The �3Ds of Mitosis� (Duplicate Distribute Divide)

$300
Dense are on the center of chromosomes (Kinteochore)

$400
Phase that sees the poles moving apart, elongating the cell (anaphase)

$500
Phase that sees the nuclear envelope reforming (what is telophase)

$600
A shallow grove in the cell surface near the old metaphase plate (what is the cleavage furrow)

$700
Phase where kinetochores of sister chromatids face opposite poles (Metaphase)

$800
Activates Cdk (cyclin)

$900
The phenomena that happens when cells stop growing because of spatial restrictions (Density-dependant inhibition)

$1000
Cancer causes this type of cell to not stop at its checkpoints (Transformed cell)

 
SEX (MEIOTIC DIVISION OF CELLS)

$100
Cell division that produces haploid cells (meiosis)

$200
Specific location of a gene on a chromosome (Locus)

$300
The smallest organizational unit of hereditary information (Gene)

$400
Type of cells formed by meiosis (gametes)

$500
The pairing of replicated homologous chromosomes during prophase I of meiosis (synapsis)
BONUS
What is the pair called? (tetrads)
EXTRA BONUS
What is the crossover point called? (chiasmata)

$600
The phase of meiosis that does not have synapsis and chiasmata where it did before (Prophase II)

$700
Known as �reduction division� (Meiosis)

$800
Results in ONE chromosome with genes from both parents (recombinant)

$900
Phase of Meiosis that has homologues separate and sister chromatids remain attached (anaphase I)
 

WHEN!?

$100
15 billion years ago (Big Bang)

$200
Era that had highlights like the origin of multicellular organisms, the origin of eukaryotes, and the creation of a viable atmosphere for aerobic life (Precambrian)

$300
Happened 3800mya (The origin of life)

$400
Era that saw plants and fungi colonize land (Paleozoic)

$500
Happened 4500mya (Origin of earth)

$600
Accumulation of atmospheric oxygen from photosynthetic cyanobacteria (2500mya)

$700
happened 10 billion years ago (planet formation)

$800
Years the planet was aerobic (1000mya, from 3500mya to 4500mya)
</pre>
=========yorg=========
===from:Jon
===date:Thu Sep 13 23:59:00 2001
===subject:Review Quiz given in SI (made by me and may not be representative of your test on Tuesday!!!)
===message:<pre>1) Which of the following is not an example of the endomembrane system?
	a) 	Golgi apparatus
	b) 	Lysosomes
	c) 	Vacuoles
	d)	All of the above are examples of the endomembrane system
        e)	None of the above are examples of the endomembrane system

2) Which of the following is not an example of passive transport?
	a)	Diffusion
	b)	Phagocytosis
	c)	Osmosis
	d)	All of the above are examples of passive transport
        e)	None of the above are examples of passive transport

3) A membrane consists of how many layers of fat?
	a) 1
	b) 2
	c) 3
	d) 4
	e) There is no fat in a membrane
 
4) Which of the following is not made in the nucleus?
	a)	Ribosomes
	b)	RNA
	c)	Lipids
	d)	DNA
        e)	all of the above are made in the nucleus

5) Which of the following is not a function of the golgi apparatus?
	a)	Modification
	b)	Storage
	c)	Synthesis
	d)	Shipping
        e)	Sorting

6) Which of the following is not a function of lysosomes?
	a)	Digesting molecules
	b)	Autophagy
	c)	Programmed cell destruction
	d)	Transportation of materials
        e)	All of the above are functions of the lysosome

7) Peroxisomes function to
	a)	Create fatty acids
	b)	Detoxify alcohol in the nervous system
	c)	Breakdown H2O2
	d)	All of the above are functions
        e)	None of the above are functions

8) Which of the following is NOT a function of the cytoskeleton
	a)	Structural support
	b)	Regulation of biochemical activities
	c)	Movement
	d)	All of the above are functions
        e)	None of the above are function

9) Which of the following is not an objective of mitosis?
	a)	Replication of DNA
	b)	Segregation of RNA to poles of the cell
	c)	Formation of two nuclei, one at each pole
	d)	Formation of cell plate in plant cells
        e)	Completion of cytokinesis in animal cells

10) In which phase does the mitotic spindle form?
	a)	Prophase
	b)	Anaphase
	c)	Telophase
	d)	Metaphase
        e)	G2
</pre>
=========yorg=========
===from:Jon
===date:Thu Sep 13 23:59:37 2001
===subject:Review Quiz Answers
===message:<pre>Answers

1-	d
2-	b
3-	b
4-	c
5-	c
6-	d
7-	e
8-	d
9-	b
10-	a
</pre>
=========yorg=========
===from:Jon
===date:Sun Sep 16 19:07:29 2001
===subject:Student multiple choice questions
===message:<pre>Student Questions

I have picked through the multiple-choice questions that were turned in at the last SI session (Thursday the 13th of Sept.) and selected twenty really good ones. 
There were a lot more really good questions but they were all pretty similar to the ones below so if you know this material forwards and backwards, you will do fine. 
Once again, this may not be representative of what you have on the test but it is a good review for it.

1) Which is not a feature that brings on variation through meiosis?
	a)	synapsis
	b)	chiasmata
	c)	crossing-over
         d)	random fusion of gametes

2) Which is not one of the �3 D�s� of cell division
	a)	Duplicate
	b)	Divide
	c)	DNA
	d)	Distribute

3) Which is not a function of a cell wall?
	a)	Protection
	b)	Matrix
	c)	Maintain Shape
         d)	Control of turgor pressure

4) Which of the following does the nucleus not have?
	a)	Nuclear Lamina
	b)	A single phospholipid bi-layer
	c)	Nuclear Pores
	d)	Double membrane

5) Peroxisomes do not do what?
	a)	Hold Water
	b)	Breakdown fatty acids
	c)	Form Peroxide
	d)	Detoxify fatty acids

6) Asexual reproduction:
	a)	Each parent contributes � of its genes to the offspring
	b)	Gives greater genetic variation than sexual reproduction
	c)	Gives an exact replica of the parent
         d)	Gives a unique combination of traits to the offspring

7) What does Cdk need to activate MPF?
	a)	Water
	b)	Cyclin
	c)	Proteoglycan
	d)	Peroxisome

8) Which of the following is not a component of the cytoskeleton?
	a)	Intermediate filaments
	b)	Microfilaments
	c)	Microtubules
	d)	Vacuoles

9) Lumen is:
	a)	The membrane covering the endoplasmic reticulum
	b)	a cavity in the ER
         c)	Organelle that creates energy for the cell
         d)	A light emitting protein

10) What did Schleidan and Schwann discover?
	a)	Light microscope
	b)	cells
	c)	cell theory
         d)	a theory on primitive earth�s atmosphere

11) What is the continuity of biological traits from one generation to the next called?
	a)	heredity
	b)	variations
	c)	genetics
	d)	DNA

12) What is the crossing over point on chromosomes called?
	a)	Synapsis
	b)	Tetrads
	c)	Chiasmata
	d)	The Mendilian area

13) Which of the following is not a fundamental principle of life?
	a)	Order
	b)	Response to Environment
	c)	Adaptation
	d)	Movement

14) Which is not a part of interphase?
	a)	S1
	b)	S2
	c)	G1
	d)	G2

15) Which of the following is only found in plants?
	a)	Food vacuole
	b)	Contractile vacuole
	c)	Central vacuole
	d)	none of the above

16) Which of the following does not have a double membrane?
	a)	Nuclear membrane
	b)	Mitochondria
	c)	Chloroplasts
	d)	Plasma membrane

17) Rough Endoplasmic Reticulum
	a)	Synthesizes proteins
	b)	Adds carbohydrates in the lumen
	c)	Has cargo departing in bubbles
	d)	all of the above

18) ______ discovered cells in ____
	a)	Schwan, 1765
	b)	Hooke, 1765
	c)	Hooke, 1665
	d)	Schwan, 1665

19) When was the origin of earth?
	a)	3500mya
	b)	4500mya
         c)	10 billion years ago
         d)	none of the above

20) In what phase do the homologous chromosomes separate but sister chromatids remain attached?
	a)	Metaphase I
	b)	Anaphase II
	c)	Anaphase I
	d)	Prophase II
</pre>
=========yorg=========
===from:Jon
===date:Sun Sep 16 19:08:32 2001
===subject:Student Multiple Choice quiz ANSWERS
===message:<pre>1-   d	(gametes fuse separate from meiosis)
2-   c	(DNA is not one of the 3 given in class)
3-   b	(It does not have a matrix)
4-   d	(It has a double membrane so the single phospholipid bi-layer is incorrect)
5-   a	(Peroxisomes do not hold water)
6-   c	(gives a clone)
7-   b	(cyclin-dependant kinase needs cyclin to activate)
8-   d	(vacuoles are not a part of the cytoskeleton)
9-   b	(a cavity in the ER)
10- c	(they found the cell theory)
11- a	(this is the definition of heredity)
12- c	(Chiasmata is the point of crossing over)
13- d 	(movement is not a fundamental principle of life)
14- b	(S is for synthesis and that only happens once)
15- c 	(the central vacuole is only fond in plants)
16- d	(the plasma membrane is a single membrane)
17- d	(all are functions of the rough ER)
18- d	(Hooke discovered cells in 1665)
19- b	(the earth was formed 4500mya)
20- c	(good question. It happens in Anaphase I, keyword: separates)
</pre>
=========yorg=========
