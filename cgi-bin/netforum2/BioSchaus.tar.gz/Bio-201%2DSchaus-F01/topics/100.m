===from:Tyler Lewis
===date:Sun Nov  4 18:44:26 2001
===subject:Assignment 8
===message:Ivertebrate Research website is www.ualberta.ca/~univhall/vp/vprea/MST99/eere/neuro.htm  The site has research focusing on characterizing dicerse neuropeptides, including structue, function, molecular biology, and mechanisms of action.  They studied how neuropeptides and biogenic amines regulate hormone secretion in gold fish. They designed nuertransmitters to act as developmental regulators which led to commercial spawning kits. They studied the nervous systems of jellyfish. They also studied the effects of water-borne pheromones on fish reproductive behavior.
=========yorg=========
===from:Ben Drescher
===email:bdresche@iastate.edu
===date:Fri Nov  9 15:41:13 2001
===subject:Monarch butterfly's migration
===message:http://www.learner.org/jnorth/spring1998/critters/monarch/bground.html 


Monarch Butterfly�s Migration



	Every spring the monarch butterfly makes the 2500-mile journey from their winter home just outside Mexico City, in the mountains. There they lived on their fat reserves and basked in the warmer climate, which protected them from the harsh North American winters.  Once they reach North America they have a short two-week window from which they need to reproduce to carry on their next generation. Through out the summer the Monarch�s offspring will reproduce spring time�s journey�s grand children migrate back to the Mountains of Mexico City for the next winter and the only navigation they have is by instinct passed down through the generations. 



Ben Drescher
02-3311 

=========yorg=========
