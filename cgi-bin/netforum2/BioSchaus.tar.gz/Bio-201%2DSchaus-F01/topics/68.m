===from:Chelsi Cervetti
===email:cervetti@iastate.edu
===date:Mon Oct 15 18:21:06 2001
===subject:regarding the comments of megan meilnik
===message:In youre argument, you stated that you believed what the bible said, that the earth and all that is in it was created in "7 days", but that a day is a metaphor for a much greater period of time.  But if you honestly are going from the bible, it clearly defines what a day is.  This is done on day 1 of creation.  Genisis 1:5-  God called the light day, and the darkness night.  And there was evening and there was morning- the first DAY.  If the word "day"  was suposed to just represent a period of time more than a day, I don't think that it would have been clearly defined as what it is now.  
=========yorg=========
