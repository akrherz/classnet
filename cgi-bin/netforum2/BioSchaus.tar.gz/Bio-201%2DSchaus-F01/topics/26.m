===from:Scott Schaus
===date:Tue Sep 25 22:40:31 2001
===subject:Down's Syndrome
===message:Hi. First, the parents don't HAVE to be older to produce a DS child; there is an increased RISK or INCIDENCE with older parents.

The are other genetic problems besides trisomy 21 that can result in DS. Trisomy 21 happens to be the most common reason, but not the only reason.

Maybe this would be a good research article paper: other, less frequent causes of Down's.


Scott
=========yorg=========
