===from:Sharon Brown
===email:scbrown@iastate.edu
===date:Mon Oct  1 14:33:31 2001
===subject:Inactivation of the X chromosome
===message:The X chromosome is inactivated so that females do not have a "double dose" of the particular traits carried on the X chromosome.  If the X chromosome is inactivated why does it still express it's genes?  Example:  If a female is heterozygous for a sex-linked trait she will express the dominant characteristic every time.  If the chromosome with the dominant trait is inactivated, why wouldn't she express the recessive trait?
Sharon Brown
=========yorg=========
