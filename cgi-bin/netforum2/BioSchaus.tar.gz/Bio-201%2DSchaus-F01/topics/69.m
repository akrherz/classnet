===from:Jennifer Anderson
===date:Mon Oct 15 14:16:52 2001
===subject:Reply
===message:You said that the big bang isn't compatible with evolutionism because evolutionists believe in a gradual change in life. But doesn't this gradualistic approach focus on how life changes? The big bang is simply a theory as to how the universe came to be the way it is. The big bang theory doesn't necessarily try to explain how life itself came to be or subsequently began to change. So couldn't the theory still apply to evolutionism? Evolutionists have to believe in natural disasters like volcano eruptions or earthquakes because they can see them today. The big bang could almost be considered to be just an extremely massive natural disaster. If it's looked at like that, evolutionists could still believe in it.
=========yorg=========
