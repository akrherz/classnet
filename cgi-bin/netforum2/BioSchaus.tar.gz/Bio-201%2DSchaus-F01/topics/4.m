===from:Nereyda Llorente
===email:ntl0812@iastate.edu
===institution:biology class
===date:Tue Aug 28 15:22:35 2001
===subject:me
===message:     Hi!  My name is Nereyda, but all my friends call me Neddy.  It is much easier to say.  I'm hispanic.  My mom is from Lima, Peru.  That's in South America.  My biologocal father is from Havanna, Cuba.  
     I am taking biology because I want to be a physical therapist.  I am a freshman in Excercise and Sports science.  I was born and raised in Des Moines, Ia.  Well hope to make friends with atleast some of you.  Sm:)e
=========yorg=========
===from:Justin Schaefer
===email:schaefej@iastate.edu
===date:Tue Aug 28 15:29:23 2001
===subject:Biology 201
===message:I am from a small town called Britt, IA.  I played football for four years in high school.  Here for a major in Agronomy.
=========yorg=========
===from:Anne Marie Zeller
===email:amzeller@iastate.edu
===date:Tue Aug 28 16:13:59 2001
===subject:Biology 201
===message:I am originally from Woodward, IA.  I graduated with 
about 55 people and was involved in everything 
imaginable.  Iowa State was my choice for college 
because I loved the campus and ISU is very  respected 
in the field of Molecular Biology.  I don't have a major 
right now,  but I am leaning towards Genetics.
=========yorg=========
===from:Christa Harms
===email:charms@iastate.edu
===date:Tue Aug 28 16:33:20 2001
===subject:Introduction
===message:Hi,
My name is Christa Harms I am in your Biol 201. I am a transfer student from NIACC, I attended Sentral of Fenton, IA high school. I was very active in sports while in high school and still enjoy them, as well as being outdoors. Hunting and fishing, are some of the ways I spend my free time, as well as just being with my friends. My major is Animal Ecology with possibly a minor in criminal justice. In the summer I work as a lake patrol, on Clear Lake for the DNR. I wish to become a Conservation Law Enforcement Officer. I hope this allows you to learn a little bit about me, see you in class!
=========yorg=========
===from:Sarah Warren
===date:Tue Aug 28 16:42:34 2001
===subject:Introduction
===message:I'm a sophmore this year majoring in biochemistry and English.  I'm originally from Mt. Pleasant, IA.  I play a lot of IMs and like going out to dinner with my friends.  That sounds like a personals ad, sorry.  My favorite color is green.  I like M&Ms.  Don't know what else to tell you.

=========yorg=========
===from:Erin Brown
===date:Tue Aug 28 18:47:58 2001
===subject:Introduction
===message:Hi everyone,
my name is Erin and I am one of the out-of-staters.  I'm originally from Pierre, South Dakota (that's pronounced like "peer,"  not "pi-air.")  I am a freshman Animal Science/Pre-Veterinary Med major contemplating a minor in Spanish.  I came to Iowa because of the vet school and because it was big enough that if I changed my mind I wouldn't have to switch schools.  I only took one year of Bio in High school so I am hoping that I can get a lot out of this class.  I like music,  playing and listening.  I play the French Horn,  Mellophone, and Bass Guitar.  I also enjoy acting.  I hope to get to know all of you better through the semester.  See you in class!
=========yorg=========
===from:Amy McCarthy
===email:amermac@iastate.edu
===date:Tue Aug 28 19:32:45 2001
===subject:Intro
===message:My name is Amy McCarthy.  I am from Dundee, IL 
(which is NW of Chicago.)  I worked at an Animal 
Hospital back home.  Now I am majoring in Animal 
Science Pre-Vet, and hope to someday become a 
D.V.M.  Until then, I plan to enjoy my days here at Iowa 
State.
=========yorg=========
===from:Jennifer Crandell
===email:J53669@yahoo.com
===institution_site:http://www.iastate.edu
===institution:ISU
===date:Tue Aug 28 23:11:33 2001
===subject:Introduction
===message:I am a fourth year architecture student and have chosen my first elective of my college career to be biology. I will hopefully graduate in two years and plan to practice in the field of restoration and preservation. I am originally from Des Moines where I have enjoyed many years of racing, currently stockcar racing, with my family. I have a grave ambition to get out of Iowa when I graduate just to enjoy the scenery.
=========yorg=========
===from:Jennifer Crandell
===email:J53669@yahoo.com
===institution_site:http://www.iastate.edu
===institution:ISU
===date:Tue Aug 28 23:11:47 2001
===subject:Introduction
===message:I am a fourth year architecture student and have chosen my first elective of my college career to be biology. I will hopefully graduate in two years and plan to practice in the field of restoration and preservation. I am originally from Des Moines where I have enjoyed many years of racing, currently stockcar racing, with my family. I have a grave ambition to get out of Iowa when I graduate just to enjoy the scenery.
=========yorg=========
===from:Josh Barnes
===email:jpbarnes@iastate.edu
===date:Wed Aug 29  9:16:17 2001
===subject:biology 201
===message: I was born in Indianapolis, Indiana, but soon moved to Earlham, Iowa. I played golf, basketball, and track. I was very fortunate to go to state in two of these sports(golf and track). This is my first year at ISU and I was planning on majoring in Landscape Architecture, but that could change any day now.
=========yorg=========
===from:Nola Lewis
===email:nlewis@iastate.edu
===date:Wed Aug 29 13:44:54 2001
===subject:Bio 201 Intro.
===message:     I am from Hampton, IA.  I'm a freshman at Iowa State majoring in Genetics (LAS).  I hope to eventually work in a crime/forensic lab testing DNA from crime scenes.  Last summer I worked at Iowa State in Volker Brendel's genetics lab.  I learned so much about genetics that I decided I would pursue it at college.
     In high school I was very active in the music program.  I am a two-year Band All-Stater (I play the clarinet).  I was involved in many clubs in HS and was in Student Council for four years.
=========yorg=========
===from:Paul Fisher
===email:pfisher@iastate.edu
===date:Wed Aug 29 14:43:58 2001
===subject:Introduction
===message:My name is Paul Fisher.  I am a second year MIS student.  I am taking Bio 201 because I would like to continue on to medeical school or chiropractic school after graduation.  I am from Okoboji, IA, where I have enjoyed many summer days of boating. 
=========yorg=========
===from:Jen Smolley
===date:Wed Aug 29 14:49:18 2001
===subject:Introduction
===message:Hello, my name is Jen Smolley, I am a sophomore here at Iowa State and I am currently a pre-business major.  I'm not sure if that's what I really want to do though.  I am from Eden Prairie, Minnesota, a suburb of Minneapolis.  I am 19 years old and my birthday is February 11.  I am living at the Alpha Chi Omega house and it's great, but there's no air conditioning in my room so it gets pretty hot.  I was at home for the summer and I am very excited to be back at school.  I absolutely love it here...
=========yorg=========
===from:Reid Rupnow
===date:Wed Aug 29 15:43:14 2001
===subject:Introduction
===message:My name is Reid Rupnow.  I am a freshmen in Animal Ecology.  I graduated from Martensdale St. Marys High School. It is a really small school about 20 minutes south of Des Moines.  I really enjoy all kinds of sports, especially baseball.  I really think this is the year, the Cubs are going to win the pennant.  
=========yorg=========
===from:Jason Wessel
===email:jswessel@iastate.edu
===date:Wed Aug 29 16:09:01 2001
===subject:Biology 201
===message:	Hello my name is Jason Wessel. I am a freshman in Ag Studies. I live at 3225 Roberts Fairchild.
	I am from Greeley Iowa. This is in northeastern Iowa. It is approximately 30 miles west of Dubuque. My parents operate a farm. We have 85 holstein dairy cows, 45 crossbred beef cattle, and we farm 600 acres of cropland. I have one brother who is a junior in Dairy Science here in Ames. I enjoy playing golf and basketball. But most of all I like to have a good time with friends and other students.
=========yorg=========
===from:J. Dustin Loy
===email:jdloy@iastate.edu
===date:Wed Aug 29 17:56:18 2001
===subject:My intro
===message:My name is Dusty Loy.  I grew up in a small town in 
central Iowa called Ames.  I  lived on a small acerage 
outside of town where we raised cattle.  My major is 
AnSci/Prevet.  
=========yorg=========
===from:Matthew Farrell
===date:Wed Aug 29 23:07:06 2001
===subject:Undecided
===message:I am from Iowa City, IA (Hawkeye country).  I was involved in Journalism, Baseball, Basketball, Football and Cross country. I am rooming with a guy from Iowa City.  He is going to try out for the ISU Football team.  I am not sure he will make it, because he is too tall.  He is also watching me type this.  Haha Brett.
I live in Knapp Hall, and I like the food service. Really, its not that bad.



=========yorg=========
===from:Jill Hoyer
===email:jhoyer@iastate.edu
===date:Thu Aug 30  9:31:35 2001
===subject:Introduction
===message:I am originally from Dubuque, IA and moved to Indianola, IA in 1994 to attend Simpson College.  I graduated from Simpson with a degree in Elementary Education in 1998 and decided not to teach.  I worked as an Underwriter for an insurance company in West Des Moines for 3 years.  During this time I decided I wanted to follow in my older brothers footsteps and become a dentist.  I am attending ISU so that I can prepare for dental school, Pre-Health Professions major.    
=========yorg=========
===from:Alicia Janas
===email:ajanas@iastate.edu
===date:Thu Aug 30 10:32:37 2001
===subject:Introduction
===message:My name is Alicia Janas and i am from Orland Park,IL (south suburb of Chicago).  I went to Carl Sandburg High School and played tennis and badminton.  (if anyone is interested in hitting, just email me)  when home, i work as a vet tech at animal welfare league.  I am going to Iowa state to major in animal science, and to eventually become a vet.
=========yorg=========
===from:whitney vogt
===email:vogtwhitney@msn.com
===date:Thu Aug 30 17:13:59 2001
===subject:introduction
===message:My name is whiotney vogt and as of now i am a genetics majior. I hope to graduate in 4 years but it may take 5. I grew up in Ankenyb Iowa and attended DMACC for one semester befor comming to Iowa State.
=========yorg=========
===from:Carri Ankrum
===date:Thu Aug 30 23:07:31 2001
===subject:Bio 201
===message:Hi my name is Carri and I am from Melbourne, Iowa which is actually only 30 minutes from Ames.  There really isn't anything interesting about me.  I am on the Iowa State Trapshooting team and the Waterski team.  I live in temp housing which is actually pretty fun.  My older sister goes here which always helps.  I am excited to get settled in and meet new people!!!!
=========yorg=========
===from:Nichola Jeffrey
===email:njeffrey@iastate.edu
===date:Fri Aug 31 15:40:52 2001
===subject:Introduction
===message:Hi. I am Nichola(Nikki) Jeffrey. I am from Madrid,IA. In high school I was involved in music and sports.  I am an Animal Science/Pre-Vet major.
=========yorg=========
===from:Adrienne Jones
===email:pinkyboo01@yahoo.com
===date:Sat Sep  1 23:32:48 2001
===subject:introduction
===message:Hi my name is Adrienne Jones and my family and I recently moved here about 2 months ago from Tennessee.I plan to major in Nursing and maybe minor in Spanish.I hope to learn a lot in this class.
=========yorg=========
===from:Justin Rinas
===date:Tue Sep  4 22:20:50 2001
===subject:Introductions
===message:Hello, mates I'm Justin! SWM I like horseback riding, syncronized swimming and Yanni.  Seriously though, I'm 
from Cedar  Rapids, Iowa, have accumulated 62 credits prior to transfering to ISU from Kirkwood Community 
College and am majoring  in Horticulture.  My goals are to own property (acrage), practice subsistance farming 
while working in a field of interest, either Horticulture or Construction. A synthesis of these two occupations 
would be landscape design.  Sounds square, well maybe.  

Musically I enjoy musicians; Coleman Hawkins, Herbie Hancock, Jerry Garcia, the B Boys and MMW(Medeski, 
Martin and Wood).  Musical genre of interest  include but are not limited to; jazz, funk, raegae, blues and folk of all 
traditions.  Hope to enjoy a successful semmester with you all get to know a few of you.  By the way horseback 
riding would be fun if I could ever get a chance, Yanni isn't  all bad and as for syncronized swimming well, ... I 
wouldn' t know , no 
=========yorg=========
