===from:Sharon Brown
===date:Mon Oct 15 20:54:44 2001
===subject:Reply
===message:I am not going to replay by debating whether creation is the reason for our existence or evolution was the way plants, animals, and humans, ect. were created.  Instead I would like to point out that we cannot simply believe things without some sort of knowledge or back up argument.  What is the point in believing if we have no idea what the truth is?  The idea of simply believing what we want to believe, leads to pure ignorance.  Believing something without reason, is as useless as believing that 1 + 1 = 4.  It is well known that that math doesn�t work.  The evolution creation debate is that same thing, we can�t set it aside to make everyone think they are correct.  One must remain open-minded and except new information.  
=========yorg=========
===from:Amy McCarthy
===date:Tue Oct 23 20:35:07 2001
===subject:Good Point
===message:I totally agree with what you said about peoples beliefs.  
No matter how much evidence there is for or against 
evolution, religious people will always stay strong 
towards their beliefs.  Since there is not any real stong 
evidence leaning either way, I feel this will be a forever 
debated topic.
=========yorg=========
===from:Brent Thompson
===email:brent75@iastate.edu
===institution:Biology 201
===date:Tue Oct 23 23:28:12 2001
===subject:Reply: Extra Credit
===message:I do believe it is okay for everyone to believe what they care to.  Christianity is what my parents taught me though, showing me how I take place in this life, but evolution seems so much more logical.  It is hard for me to understand how the universe was created by God in those seven days everybody talks about.  The theory of evolution clears up most questions a christian would have about how they got here.  It delievers proof, something the Bible fails at.  The way things happen, such as genetic drift, gene flow and natural selection show me exactly how the animal, life forms, and humans are in existance today.  This process is ongoing.  Is God changing it right now, as I sit here and type this?  Why is it taking him so long to do it, it takes so many years for a species to become extinct or a new species to come into our world.  With the over population we have on Earth, why doesn't God create life on another planet which can flourish and replicate Earth?  Whether these questions are offending to Christians or not, it explains the logic of evolution.  Is it okay to believe in both Christianity and evolution?  Because of what we were taught from our ancestors, Christianity seems to be the way the majority of the North American continent leads to, but what if our ancestors preached evolution, then would we be studying more about Christianity and have people believe it "religiously wrong for us to believe a sort of Christianity?"  
=========yorg=========
