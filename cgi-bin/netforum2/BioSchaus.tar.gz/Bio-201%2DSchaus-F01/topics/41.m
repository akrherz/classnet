===from:Matt Farrell
===date:Thu Oct 11 22:44:05 2001
===subject:Abstract Thoughts
===message:I agree very much with your conclusion; science is not the only tool of knowledge, and evolution could not occur without creation.
Humans are the only species to do alot of things (intelligence and feelings are among the most unigue), but we ARE a species, like everything else.  Science and Philosophy are extended tools of are mind, which I believe was only created for the purpose of survival (the natural selection of humans is another topic entirely).  We use science and philosophy to answer unanswerable questions; questions that only humans create, and only humans have the ability to ponder.  Proof of this can be seen by the fact that humans become more and more abstract and philosophical as they grow older (look at ourselves, in college, hardly concerned about where to get the food we eat).  Therefore, humans are only a unique species who, like other animals dominaters of the world before us, have gone beyond the boundaries of survival, and created our own pyschological world.   What can truly set us apart from other species, is the slim chance we have to be able to live forever, and to do this we must cultivate other planets.  This is also another topic, but I just wanted to get my message across to all the Republicans who believe we should cut Space Program Funding.  Don't think I have any love for Democrats either, mind you! 
=========yorg=========
===from:Kayla Tott
===date:Sat Oct 13 21:07:30 2001
===subject:Reply
===message:The Bible is a great source for knowledge.  I can see where one with not as strong of faith would be a little skeptical, or for an atheist to use evolution as something to back their beliefs on.  But I think creation and evolution are compatible with one another.  The way the Bible explains creation may not have exactly happened 'poof' like that.  Those with strong faith and religious values probably take the creation story too literal.  We don't know how long those seven days were, they may not be equivilant to the seven days that we know now.  I think how the world was created is too complex for anyone to fully understand.  The creation story is just a way for us to simply understand.  Evolution and creation have to go hand in hand.  Species are always gradually evolving.  
=========yorg=========
===from:Kelli Kopf
===date:Sun Oct 14 20:31:35 2001
===subject:Knowledge
===message:I agree that science is not the only valid form of knowledge. I do however believe that science is viewed as being the highest form of knowledge in our society.  A doctor is considered a very important profession in the American society.  A person with a doctorate in a scientific field is viewed as being much higher or more "important" in society than a person with a doctorate in a non-scientific field.  A doctor is viewed as being much more important than a teacher.  Also, in other cultures, science is not the most valid form of knowledge.  In the Native American culture, religion and vision are considered the highest forms of knowledge.  The spiritual leader/medicine man is considered the highest position in the tribe next to the chief.  Spiritual knowledge is seeked by everyone, and scientific discoveries is not at the top of the "to do" list.  I thought that Group #6's discussion was valid, but i think that they may have over-looked other cultures.  
=========yorg=========
===from:Sarah Fowler
===date:Thu Oct 18 14:06:34 2001
===subject:Group #6- a response
===message:You guys stated that knowledge is based on a person's belief's and experiences?  How are belief's valid forms of knowledge?  I believe that science is the only valid form of knowledge because it is the only thing that can be proven.  You can't prove that God put the first thing on this Earth and evolution took off from that.  But you can prove with science how things have evolved.  
=========yorg=========
