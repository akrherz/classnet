===from:Kellen Ludvigson
===date:Sun Oct 14 10:55:34 2001
===subject:response
===message:I thought the information about the whales and about humans being able to see ultraviolet light visible underwater was interesting.  However, my question to you is if humans were water dwelling, why don't we find evidence of human-like animals in fossils or in some other form of preservation?  
=========yorg=========
