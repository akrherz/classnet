===from:Blessie Zacharia
===date:Mon Oct 15 18:53:20 2001
===subject:true...
===message:It's true, people were scared to present new ideas (or to defy old ideas) because they were scared of what society would think of them (like in Darwin's example).  Christopher Columbus also had to defy the "known" knowledge that the world was flat, even though society shunned him thinking such absurd things. These people had to think for themselves, and share what they thought to be the truth.
=========yorg=========
